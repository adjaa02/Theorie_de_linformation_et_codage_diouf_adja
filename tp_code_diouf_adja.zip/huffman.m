function [codes, Lmoy] = huffman(p)
%HUFFMAN  Construit le code de Huffman d'une source sans mémoire.
%   [codes, Lmoy] = huffman(p)
%   p     : vecteur des probabilités des symboles (somme = 1)
%   codes : cellule, codes{i} = mot de code (chaîne de '0' et '1') du symbole i
%   Lmoy  : longueur moyenne du code (bits par symbole)
%
%   Principe : on fusionne de proche en proche les deux noeuds les moins
%   probables. Chaque fusion ajoute un bit EN TETE du code de tous les
%   symboles contenus dans les deux noeuds ('0' pour l'un, '1' pour l'autre).

p = p(:);
n = numel(p);

if n == 1                           % cas dégénéré : un seul symbole
    codes = {'0'};
    Lmoy = 1;
    return;
end

codes    = repmat({''}, n, 1);      % mots de code, construits à l'envers
w        = p;                       % poids des noeuds encore actifs
membres  = num2cell((1:n)');        % membres{k} = symboles contenus dans le noeud k

while numel(w) > 1
    [w, ordre] = sort(w, 'ascend'); % les deux moins probables en tête
    membres = membres(ordre);

    for s = membres{1}              % noeud le moins probable -> bit '0'
        codes{s} = ['0' codes{s}];
    end
    for s = membres{2}              % second moins probable   -> bit '1'
        codes{s} = ['1' codes{s}];
    end

    % fusion des deux noeuds en un seul
    w       = [w(1) + w(2); w(3:end)];
    membres = [{[membres{1} membres{2}]}; membres(3:end)];
end

Lmoy = sum(p .* cellfun(@numel, codes));
end