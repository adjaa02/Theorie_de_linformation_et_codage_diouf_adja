function idx = huffman_decode(bits, codes)
%HUFFMAN_DECODE  Décode un flux binaire codé avec un code de Huffman.
%   idx = huffman_decode(bits, codes)
%   bits  : chaîne de '0' et '1'
%   codes : cellule des mots de code (sortie de huffman)
%   idx   : indices des symboles décodés
%
%   Principe : le code est préfixe, donc dès que les bits lus forment un mot
%   de code, c'est forcément le bon : on émet le symbole et on repart de zéro.
%   Le décodage est instantané, sans séparateur entre les mots.

table = containers.Map(codes, num2cell(1:numel(codes)));  % mot de code -> indice

N   = numel(bits);
idx = zeros(1, N);        % taille maximale (au plus un symbole par bit)
k   = 0;                  % nombre de symboles décodés
deb = 1;                  % début du mot en cours de lecture

for i = 1:N
    mot = bits(deb:i);            % bits lus depuis le début du mot courant
    if isKey(table, mot)          % un mot de code complet a été reconnu
        k = k + 1;
        idx(k) = table(mot);
        deb = i + 1;              % le mot suivant commence au bit suivant
    end
end

idx = idx(1:k);
end