function h = rrc_coeffs(alpha, L, span)
%RRC_COEFFS  Réponse impulsionnelle du filtre en racine de cosinus surélevé, d'énergie unité.
%   h = rrc_coeffs(alpha, L, span)
%   alpha : facteur de retombée (roll-off)
%   L     : nombre d'échantillons par durée symbole T (T = 1)
%   span  : durée du filtre en nombre de symboles (N = span*L + 1 coefficients)
%
%   h_alpha(t) = (1/sqrt(T)) [ (4 alpha/pi) cos(pi (1+alpha) t/T) + (1-alpha) sinc((1-alpha) t/T) ]
%                            / [ 1 - (4 alpha t/T)^2 ]
%   Deux points sont singuliers (0/0), on utilise leurs limites (règle de l'Hôpital) :
%     t = 0           : h(0)         = (1 - alpha + 4 alpha/pi) / sqrt(T)
%     t = +-T/(4 alpha) : h(T/(4 alpha)) = alpha/sqrt(2T) [ (1+2/pi) sin(pi/(4 alpha)) + (1-2/pi) cos(pi/(4 alpha)) ]
%   Le filtre est ensuite normalisé pour que sum(h.^2) = 1 (énergie unité).

N = span * L + 1;
t = (-(N-1)/2 : (N-1)/2) / L;           % temps en unités de T
h = zeros(1, N);
for n = 1:N
    tn = t(n);
    if abs(tn) < 1e-12                                       % t = 0
        h(n) = 1 - alpha + 4*alpha/pi;
    elseif alpha > 0 && abs(abs(tn) - 1/(4*alpha)) < 1e-9    % t = +-T/(4 alpha)
        h(n) = alpha/sqrt(2) * ((1 + 2/pi) * sin(pi/(4*alpha)) + (1 - 2/pi) * cos(pi/(4*alpha)));
    else
        x = (1 - alpha) * tn;
        if abs(x) < 1e-12, sc = 1; else, sc = sin(pi*x) / (pi*x); end   % sinc(x) = sin(pi x)/(pi x)
        h(n) = (4*alpha/pi * cos(pi*(1 + alpha)*tn) + (1 - alpha) * sc) / (1 - (4*alpha*tn)^2);
    end
end
h = h / sqrt(sum(h.^2));                % énergie unité
end