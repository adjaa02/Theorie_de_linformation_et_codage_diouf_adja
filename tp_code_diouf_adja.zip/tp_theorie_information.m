%% ========================================================================
%  TP Theorie de l'information et codage - ENSIM 5A ASTRE
%  DIOUF Adja
%
%  Script principal : parties 2 a 8 du sujet (Matlab). Chaque partie est decoupee en
%  sections ("%%"). Lancer le script en entier (Run) ; pour relancer une section seule,
%  avoir execute auparavant la section 0 et les sections dont elle depend.
%
%  Fichiers necessaires dans le meme dossier :
%    - donnees : longtexte.txt
%    - fonctions du TP : parametres_perso, source, entropie, huffman, huffman_code,
%      huffman_decode, comparer_codages, lz78_encode, lz78_decode, cbs, reste_g,
%      hamming_GH, hamming_encode, hamming_decode, pb_hamming, rrc_coeffs, oeil,
%      teb_chaine_filtree, teb_canal_echo, transmet_bits
%  Les modeles Simulink (chaine_base.slx) ne servent qu'a la section 3.5, facultative.
%% ========================================================================

%% 0. Initialisation : parametres personnels et outils communs
clear; clc; close all;

P  = parametres_perso('DIOUF Adja');        % parametres propres a l'etudiant
Q  = @(x) 0.5 * erfc(x / sqrt(2));          % fonction Q (queue de la loi normale)
Hb = @(p) -p.*log2(p) - (1-p).*log2(1-p);   % entropie binaire H(p)
utiliser_simulink = false;                  % true : lance aussi la section 3.5 (modele chaine_base)

fprintf('Etudiant : %s\n', P.nom);
fprintf('p1 = %.2f, p1_ext = %.2f, pe_cbs = %.3f, a_unif = %.2f, sigma = %.2f\n', ...
        P.p1, P.p1_ext, P.pe_cbs, P.a_unif, P.sigma);
fprintf('L = %d, alpha = %.2f, beta = %.2f, retard du trajet = %d symbole(s)\n', ...
        P.L, P.alpha, P.beta, P.retard_trajet);


%% ========================================================================
%  PARTIE 2 : CODAGE DE SOURCE
%% ========================================================================

%% 2.1 Source binaire sans memoire : generateur et debit d'information
rng(P.graine);
p1 = P.p1;
fprintf('p1 = %.2f   p0 = %.2f\n', p1, 1 - p1);

b_src = source(1e5, p1);                    % 1e5 bits, P(1) = p1
fprintf('Frequence empirique des 1 : %.4f\n', mean(b_src));

Hs = Hb(p1);
fprintf('H(p1) = %.4f bit/symbole\n', Hs);
fprintf('Debit d''information a 1 bit/s : %.4f bit/s\n', Hs * 1);

pp = linspace(1e-6, 1 - 1e-6, 1000);
figure; plot(pp, Hb(pp), 'b', 'LineWidth', 1.5); hold on;
plot(p1, Hs, 'ro', 'MarkerFaceColor', 'r');
plot([0.5 0.5], [0 1], 'k:');
grid on; xlabel('p'); ylabel('H(p) (bit/symbole)');
title('Entropie d''une source binaire H(p)');
legend('H(p)', sprintf('Ma source : p_1 = %.2f, H = %.3f', p1, Hs), 'p = 0,5 (maximum)', 'Location', 'south');

%% 2.2 Codage de Huffman d'un texte
% --- 2.2.3 Caracteristiques du texte ---
texte = fileread('longtexte.txt', 'Encoding', 'UTF-8');
Nc = numel(texte);
[H0, sym, pt] = entropie(texte);            % entropie d'ordre 0, alphabet, probabilites
fprintf('\nNombre de caracteres : %d\n', Nc);
fprintf('Taille de l''alphabet : %d\n', numel(sym));
fprintf('Entropie : %.3f bit/caractere\n', H0);
fprintf('Code de longueur fixe : %d bits\n', ceil(log2(numel(sym))));
fprintf('Redondance vs 8 bits : %.3f bit/car (%.1f %%)\n', 8 - H0, 100 * (1 - H0/8));

[ps, ordre] = sort(pt, 'descend');          % 20 caracteres les plus frequents
n20 = 20;
figure; bar(ps(1:n20));
lab = cellstr(sym(ordre(1:n20))');
lab(strcmp(lab, ' ')) = {'esp'};
set(gca, 'XTick', 1:n20, 'XTickLabel', lab);
xlabel('Caractere'); ylabel('Frequence'); title('Les 20 caracteres les plus frequents');

% --- 2.2.4 Validation de huffman sur une source connue ---
p5 = [0.4 0.2 0.2 0.1 0.1];
[codes5, L5] = huffman(p5);
for i = 1:numel(p5)
    fprintf('symbole %d  p = %.2f  code = %s\n', i, p5(i), codes5{i});
end
fprintf('Longueur moyenne : %.3f bits (attendue 2.2)\n', L5);
lg5 = cellfun(@numel, codes5);
fprintf('Somme de Kraft : %.3f (attendue 1)\n', sum(2.^(-lg5)));
prefixe = true;                             % aucun mot n'est le debut d'un autre
for i = 1:numel(codes5)
    for j = 1:numel(codes5)
        if i ~= j && strncmp(codes5{i}, codes5{j}, numel(codes5{i})), prefixe = false; end
    end
end
fprintf('Code prefixe : %d (attendu 1)\n', prefixe);
H5 = -sum(p5 .* log2(p5));
fprintf('Entropie H = %.3f ; H <= Lmoy < H+1 : %d\n', H5, H5 <= L5 && L5 < H5 + 1);

% --- 2.2.5 Codeur / decodeur sur le long texte ---
[~, idx_txt] = ismember(texte, sym);        % caractere -> indice dans l'alphabet
[codes, Lmoy] = huffman(pt);
fprintf('\nLongueur moyenne Lmoy = %.3f bit/car, efficacite H/Lmoy = %.4f\n', Lmoy, H0 / Lmoy);
fprintf('H <= Lmoy < H+1 ? %d\n', H0 <= Lmoy && Lmoy < H0 + 1);

flux_huff = huffman_code(idx_txt, codes);   % flux binaire (chaine de '0' et '1')
fprintf('Longueur reelle du flux : %d bits -> %.3f bit/car\n', numel(flux_huff), numel(flux_huff) / Nc);
texte2 = sym(huffman_decode(flux_huff, codes));
if size(texte2, 1) > 1, texte2 = texte2.'; end
fprintf('Texte restitue sans erreur ? %d\n', isequal(texte, texte2));
Lfixe = ceil(log2(numel(sym)));
fprintf('Taux de compression vs 8 bits : %.3f (gain %.1f %%)\n', 8*Nc/numel(flux_huff), 100*(1 - numel(flux_huff)/(8*Nc)));
fprintf('Taux de compression vs longueur fixe (%d bits) : %.3f\n', Lfixe, Lfixe*Nc/numel(flux_huff));
compression_huffman = 8 * Nc / numel(flux_huff);

lg = cellfun(@numel, codes);
figure; plot(-log2(pt), lg, 'bo', 'MarkerFaceColor', 'b'); hold on;
plot([0 max(lg)], [0 max(lg)], 'r--'); grid on;
xlabel('-log_2(p) : information propre du caractere (bits)'); ylabel('Longueur du mot de Huffman (bits)');
title('Huffman : longueur du mot de code vs -log_2(p)');
legend('Caracteres', 'Longueur = -log_2(p)', 'Location', 'northwest');

% --- 2.2.6 Cout de transmission de la table de codage ---
n_sym = numel(sym);
b_sym = 8;                                  % bits pour designer un symbole (hypothese du sujet)
b_len = ceil(log2(max(lg) + 1));            % bits pour donner la longueur d'un mot de code
C_naif  = n_sym * (b_sym + b_len) + sum(lg);% symbole + longueur + mot de code
C_canon = n_sym * (b_sym + b_len);          % code canonique : le mot est reconstruit par le decodeur
fprintf('\nAlphabet : %d symboles, mots de %d a %d bits\n', n_sym, min(lg), max(lg));
fprintf('Cout de la table (naif)      : %d bits\n', C_naif);
fprintf('Cout de la table (canonique) : %d bits\n', C_canon);
fprintf('Compression rentable a partir de N = %.0f caracteres\n', C_naif / (8 - Lmoy));
fprintf('Cout < 1 %% du flux compresse a partir de N = %.0f caracteres\n', 100 * C_naif / Lmoy);

Nl = logspace(1, 6, 200);
figure; semilogx(Nl, Lmoy + C_naif ./ Nl, 'b', 'LineWidth', 1.5); hold on;
semilogx(Nl, 8*ones(size(Nl)), 'r--'); semilogx(Nl, Lmoy*ones(size(Nl)), 'k:');
grid on; ylim([0 16]); xlabel('Longueur du texte N (caracteres)'); ylabel('Bits par caractere (table incluse)');
title('Cout reel du codage de Huffman, table de codage incluse');
legend('Huffman + table', '8 bits/car (sans compression)', 'L moyen (table ignoree)');

%% 2.3 Extension de la source et premier theoreme de Shannon
rng(P.graine);
pext = P.p1_ext;                            % source tres desequilibree
Hext = Hb(pext);
fprintf('\np1_ext = %.2f   H = %.4f bit/symbole\n', pext, Hext);
bsrc = source(1e5, pext);                   % source de 1e5 bits pour verifier par codage reel

K = 1:10;                                   % taille des blocs
Lth = zeros(size(K));  Lemp = zeros(size(K));
for k = K
    blocs = dec2bin(0:2^k-1) - '0';         % les 2^k blocs possibles
    w  = sum(blocs, 2);                     % nombre de 1 par bloc
    pb = (pext.^w) .* ((1 - pext).^(k - w));% probabilite de chaque bloc
    [codes_k, Lk] = huffman(pb);
    Lth(k) = Lk / k;                        % bits par bit de source (theorique)

    nb  = floor(1e5 / k);                   % verification : on code reellement la source
    Bk  = reshape(bsrc(1:nb*k), k, nb).';
    ik  = Bk * (2.^(k-1:-1:0)).' + 1;       % bloc -> indice 1..2^k
    lgk = cellfun(@numel, codes_k);
    Lemp(k) = sum(lgk(ik)) / (nb * k);
    fprintf('k=%2d  mots=%4d  Lk/k theorique=%.4f  mesure=%.4f\n', k, 2^k, Lth(k), Lemp(k));
end
figure; plot(K, Lth, 'bo-', 'LineWidth', 1.5, 'MarkerFaceColor', 'b'); hold on;
plot(K, Lemp, 'gs--', 'LineWidth', 1); plot(K, Hext*ones(size(K)), 'r-', 'LineWidth', 1.5);
plot(K, Hext + 1./K, 'k:', 'LineWidth', 1.5); grid on;
xlabel('Taille k des blocs'); ylabel('Bits par bit de source');
title(sprintf('Extension de la source (p_1 = %.2f) : L_k/k vers H', pext));
legend('L_k/k (theorique)', 'L_k/k (mesure sur 10^5 bits)', 'Entropie H', 'Borne H + 1/k', 'Location', 'northeast');

%% 2.4 Source avec memoire et compresseurs reels
fprintf('\n--- Texte complet (%d caracteres) ---\n', Nc);
R1 = comparer_codages(texte, 'longtexte');
fprintf('--- 5000 premiers caracteres ---\n');
R2 = comparer_codages(texte(1:5000), 'texte_5000');

noms = {'Longueur fixe', 'H ordre 0', 'Huffman', 'H(X1X2)/2', 'gzip', 'bzip2', '7z'};
v1 = [R1.fixe R1.H0 R1.huff R1.H2 R1.gzip R1.bzip2 R1.sevenz];
v2 = [R2.fixe R2.H0 R2.huff R2.H2 R2.gzip R2.bzip2 R2.sevenz];
fprintf('\n%-15s %14s %14s   (bits/caractere)\n', '', 'texte complet', '5000 car.');
for i = 1:numel(noms), fprintf('%-15s %14.3f %14.3f\n', noms{i}, v1(i), v2(i)); end
figure; bar([v1; v2].'); set(gca, 'XTickLabel', noms); grid on; ylabel('Bits par caractere');
title('Codage d''un texte : de la longueur fixe aux compresseurs');
legend('Texte complet', '5000 premiers caracteres', 'Location', 'northeast');

% Question 9 : le flux de sortie de Huffman est-il aleatoire ?
bh   = double(flux_huff == '1');            % flux de Huffman en 0/1
p1s  = mean(bh);
ICs  = 1.96 * sqrt(p1s * (1 - p1s) / numel(bh));
prs  = 2*bh(1:end-1) + bh(2:end) + 1;       % paires de bits -> 1..4
fprintf('\nSortie de Huffman (%d bits) : proportion de 1 = %.4f +/- %.4f (IC 95 %%)\n', numel(bh), p1s, ICs);
fprintf('Entropie des paires / 2 = %.4f (maximum 1)\n', entropie(prs) / 2);
octets  = unicode2native(texte, 'UTF-8');   % contraste : texte brut en octets
braw    = reshape((dec2bin(octets, 8) - '0').', 1, []);
prs_raw = 2*braw(1:end-1) + braw(2:end) + 1;
fprintf('Texte brut en octets : proportion de 1 = %.4f, entropie des paires / 2 = %.4f\n', mean(braw), entropie(prs_raw) / 2);

%% 2.5 Codage de Lempel-Ziv (LZ78)
rng(P.graine);
ex  = 'ABAABABAABAB';                       % exemple du sujet
seq = ex - 'A' + 1;                         % A -> 1, B -> 2
[lz_idx, lz_sym] = lz78_encode(seq, 2);
fprintf('\nExemple : %s\n', ex);
for i = 1:numel(lz_idx)
    if lz_sym(i) == 0, fprintf('(%d,fin) ', lz_idx(i)); else, fprintf('(%d,%c) ', lz_idx(i), 'A' + lz_sym(i) - 1); end
end
fprintf('\nAttendu : (0,A) (0,B) (1,A) (2,A) (4,A) (4,B)\n');
fprintf('Decodage identique a l''original ? %d\n\n', isequal(lz78_decode(lz_idx, lz_sym), seq));

% cout : le i-eme couple demande ceil(log2 i) bits d'indice + ceil(log2 M) bits de symbole
cout = @(n, M) sum(ceil(log2(1:n))) + n * ceil(log2(M));

for Nt = [Nc, 5000]                         % texte complet puis 5000 premiers caracteres
    t = texte(1:Nt);
    [sy, ~, s] = unique(t);
    M = numel(sy);
    [ii, ss] = lz78_encode(s(:).', M);
    ok = isequal(lz78_decode(ii, ss), s(:).');
    fprintf('Texte, %6d car. : %5d phrases, LZ78 = %.3f bit/car (H0 = %.3f), decodage OK : %d\n', ...
            Nt, numel(ii), cout(numel(ii), M) / Nt, entropie(t), ok);
end

Ns = [1e3 3e3 1e4 3e4 1e5 3e5 1e6];        % source binaire p1_ext, longueur croissante
Lz = zeros(size(Ns));
fprintf('\nSource binaire p1_ext = %.2f, H = %.4f\n', pext, Hext);
for j = 1:numel(Ns)
    bb = source(Ns(j), pext) + 1;           % symboles 1 et 2
    [ii, ss] = lz78_encode(bb, 2);
    Lz(j) = cout(numel(ii), 2) / Ns(j);
    fprintf('N = %7d : %6d phrases, LZ78 = %.4f bit/bit\n', Ns(j), numel(ii), Lz(j));
end
figure; semilogx(Ns, Lz, 'bo-', 'LineWidth', 1.5, 'MarkerFaceColor', 'b'); hold on;
semilogx(Ns, Hext*ones(size(Ns)), 'r-', 'LineWidth', 1.5); semilogx(Ns, ones(size(Ns)), 'k:'); grid on;
xlabel('Longueur du message N (bits)'); ylabel('Bits par bit de source');
title(sprintf('LZ78 sur une source binaire (p_1 = %.2f) : convergence vers H', pext));
legend('LZ78', 'Entropie H', '1 bit/bit (sans compression)', 'Location', 'northeast');


%% ========================================================================
%  PARTIE 3 : CANAL ET DETECTION
%% ========================================================================

%% 3.1 Canal binaire symetrique (CBS)
rng(P.graine);
pe = P.pe_cbs;
fprintf('\npe = %.3f\n', pe);

N = 1e6;                                    % TEB simule et intervalle de confiance a 95 %
b = source(N, P.p1);
r = cbs(b, pe);
teb = mean(r ~= b);
ic  = 1.96 * sqrt(teb * (1 - teb) / N);
fprintf('TEB simule = %.5f +/- %.5f (IC 95 %%), nombre d''erreurs = %d\n', teb, ic, sum(r ~= b));
fprintf('pe appartient a l''IC ? %d\n', abs(teb - pe) <= ic);

pes = [0.01 0.02 0.05 0.1 0.2 0.3 0.4 0.5];  % le TEB doit suivre la droite TEB = pe
tebs = zeros(size(pes));  ics = zeros(size(pes));
for i = 1:numel(pes)
    bb = source(N, P.p1);  rr = cbs(bb, pes(i));
    tebs(i) = mean(rr ~= bb);
    ics(i)  = 1.96 * sqrt(tebs(i) * (1 - tebs(i)) / N);
    fprintf('pe = %.2f : TEB = %.5f +/- %.5f\n', pes(i), tebs(i), ics(i));
end
figure; errorbar(pes, tebs, ics, 'bo', 'MarkerFaceColor', 'b'); hold on; plot([0 0.5], [0 0.5], 'r--'); grid on;
xlabel('p_e (probabilite d''erreur du canal)'); ylabel('TEB simule');
title('Canal binaire symetrique : TEB simule vs p_e');
legend('Simulation (IC 95 %)', 'TEB = p_e', 'Location', 'northwest');

C = 1 - Hb(pe);                             % capacite du CBS
Rh = 4/7;                                   % rendement du code de Hamming (7,4)
p_seuil = fzero(@(p) 1 - Hb(p) - Rh, [1e-6, 0.5 - 1e-6]);
fprintf('\nCapacite C(pe) = %.4f bit par bit emis\n', C);
fprintf('Rendement R = 4/7 = %.4f ; R < C ? %d\n', Rh, Rh < C);
fprintf('C(p) = 4/7 pour p = %.4f (fiable si pe < %.4f) ; C(0,5) = %.4f\n', p_seuil, p_seuil, 1 - Hb(0.5));
pc_cap = linspace(1e-6, 1 - 1e-6, 1000);
figure; plot(pc_cap, 1 - Hb(pc_cap), 'b', 'LineWidth', 1.5); hold on;
plot(pe, C, 'ro', 'MarkerFaceColor', 'r'); plot([0 1], [Rh Rh], 'k--'); plot(p_seuil, Rh, 'ks', 'MarkerFaceColor', 'k'); grid on;
xlabel('p_e'); ylabel('Capacite C (bit par bit emis)'); title('Capacite du canal binaire symetrique C(p_e) = 1 - H(p_e)');
legend('C(p_e)', sprintf('Mon canal : p_e = %.3f, C = %.3f', pe, C), 'R = 4/7 (Hamming)', sprintf('Seuil p_e = %.3f', p_seuil), 'Location', 'south');

%% 3.2 Canal a bruit uniforme sur [-a, a]
rng(P.graine);
A = P.A;  a = P.a_unif;  p1 = P.p1;  p0 = 1 - p1;
fprintf('\nA = %.2f, a = %.2f, p1 = %.2f, p0 = %.2f\n', A, a, p1, p0);
fprintf('a > A ? %d ; largeur de la zone de recouvrement 2(a-A) = %.3f\n', a > A, 2*(a - A));

% densites f(r|0), f(r|1) et seuil optimal (regle du MAP)
r  = linspace(-A-a-0.5, A+a+0.5, 4000);
f0 = (abs(r + A) <= a) / (2*a);             % bit 0 : x = -A
f1 = (abs(r - A) <= a) / (2*a);             % bit 1 : x = +A
figure; hold on;
patch([A-a a-A a-A A-a], [0 0 1/(2*a) 1/(2*a)], [0.85 0.85 0.85], 'EdgeColor', 'none');
plot(r, f0, 'b', 'LineWidth', 1.5); plot(r, f1, 'r', 'LineWidth', 1.5); grid on; ylim([0, 1.4/(2*a)]);
xlabel('r'); ylabel('Densite de probabilite'); title(sprintf('Bruit uniforme : f(r|0) et f(r|1) (A = %.0f, a = %.2f)', A, a));
legend('Zone de recouvrement [A-a, a-A]', 'f(r|0)', 'f(r|1)', 'Location', 'north');

% Dans la zone de recouvrement les deux densites sont egales : tout depend de p1 et p0
if p1 > p0, s_opt_u = A - a; elseif p1 < p0, s_opt_u = a - A; else, s_opt_u = 0; end
fprintf('Seuil optimal theorique s* = %.3f\n', s_opt_u);

% Pe(s) : decision "1" si r > s ; lois uniformes, donc fonctions affines saturees
Pe_u = @(s) p0 * min(max((a - A - s)/(2*a), 0), 1) + p1 * min(max((s - A + a)/(2*a), 0), 1);
fprintf('Pe(s*) theorique = %.4f (formule min(p0,p1)(a-A)/a = %.4f)\n', Pe_u(s_opt_u), min(p0,p1)*(a-A)/a);
fprintf('Pe(0)  theorique = %.4f (formule (a-A)/(2a) = %.4f)\n', Pe_u(0), (a - A)/(2*a));

N = 1e6;                                    % simulation : meme tirage pour tous les seuils
b  = source(N, p1);
rr = A * (2*b - 1) + a * (2*rand(1, N) - 1);
s_grid = unique([linspace(-(A+a)-0.2, (A+a)+0.2, 81), s_opt_u, 0]);
teb = arrayfun(@(s) mean((rr > s) ~= b), s_grid);
[tmin, imin] = min(teb);
fprintf('\nTEB minimal simule = %.4f pour s = %.3f\n', tmin, s_grid(imin));
fprintf('TEB simule en s* = %.4f ; theorie %.4f\n', mean((rr > s_opt_u) ~= b), Pe_u(s_opt_u));
fprintf('TEB simule en 0  = %.4f ; theorie %.4f\n', mean((rr > 0) ~= b), Pe_u(0));
fprintf('Gain de s* par rapport a s = 0 : facteur %.2f\n', Pe_u(0) / Pe_u(s_opt_u));
figure; hold on; plot(s_grid, Pe_u(s_grid), 'r-', 'LineWidth', 1.5);
plot(s_grid, teb, 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 4);
plot([s_opt_u s_opt_u], [0 1.05*max(Pe_u(s_grid))], 'k--'); grid on;
xlabel('Seuil de decision s'); ylabel('Probabilite d''erreur');
title(sprintf('Bruit uniforme : TEB en fonction du seuil (p_1 = %.2f, a = %.2f)', p1, a));
legend('Theorie', 'Simulation (10^6 bits)', sprintf('Seuil optimal s* = %.2f', s_opt_u), 'Location', 'north');

%% 3.3 Canal a bruit blanc gaussien
rng(P.graine);
sg = P.sigma;
fprintf('\nA = %.2f, sigma = %.2f, p1 = %.2f, p0 = %.2f\n', A, sg, p1, p0);

s_opt_g = sg^2 / (2*A) * log(p0 / p1);                   % seuil du MAP
Pe_g = @(s) p0 * Q((s + A)/sg) + p1 * Q((A - s)/sg);     % Pe(s)
fprintf('Seuil optimal theorique s* = %.4f\n', s_opt_g);
fprintf('Pe(s*) = %.5f\n', Pe_g(s_opt_g));
fprintf('Pe(0)  = %.5f   (= Q(A/sigma) = %.5f, independant de p1)\n', Pe_g(0), Q(A/sg));

% densites ponderees p0 f(r|0) et p1 f(r|1) : elles se croisent en s*
r  = linspace(-A-4*sg, A+4*sg, 2000);
gs = @(r, m) exp(-(r - m).^2 / (2*sg^2)) / (sg*sqrt(2*pi));
figure; hold on; plot(r, p0*gs(r, -A), 'b', 'LineWidth', 1.5); plot(r, p1*gs(r, A), 'r', 'LineWidth', 1.5);
yl = ylim; plot([s_opt_g s_opt_g], yl, 'k--'); plot([0 0], yl, 'g:', 'LineWidth', 1.5); grid on;
xlabel('r'); ylabel('Densite ponderee'); title(sprintf('Bruit gaussien : p_0 f(r|0) et p_1 f(r|1) (\\sigma = %.2f)', sg));
legend('p_0 f(r|0)', 'p_1 f(r|1)', sprintf('Seuil optimal s* = %.3f', s_opt_g), 'Seuil s = 0');

N = 1e6;                                    % TEB simule en fonction du seuil
b  = source(N, p1);
rr = A * (2*b - 1) + sg * randn(1, N);
s_grid = unique([linspace(-A, A, 81), s_opt_g, 0]);
teb = arrayfun(@(s) mean((rr > s) ~= b), s_grid);
teb_opt = mean((rr > s_opt_g) ~= b);  teb_zero = mean((rr > 0) ~= b);
ic_opt = 1.96 * sqrt(teb_opt * (1 - teb_opt) / N);
fprintf('\nTEB simule en s* = %.5f +/- %.5f ; theorie %.5f ; dans l''IC ? %d\n', ...
        teb_opt, ic_opt, Pe_g(s_opt_g), abs(teb_opt - Pe_g(s_opt_g)) <= ic_opt);
fprintf('TEB simule en 0  = %.5f ; theorie %.5f\n', teb_zero, Pe_g(0));
fprintf('Gain de s* par rapport a s = 0 : %.5f en absolu, facteur %.3f (%.1f %% de moins)\n', ...
        Pe_g(0) - Pe_g(s_opt_g), Pe_g(0)/Pe_g(s_opt_g), 100*(1 - Pe_g(s_opt_g)/Pe_g(0)));
[~, imin] = min(teb);
fprintf('Seuil du TEB simule minimal : %.3f (theorie %.3f ; courbe plate pres du minimum)\n', s_grid(imin), s_opt_g);
figure; hold on; plot(s_grid, Pe_g(s_grid), 'r-', 'LineWidth', 1.5);
plot(s_grid, teb, 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 4);
yl = ylim; plot([s_opt_g s_opt_g], yl, 'k--'); plot([0 0], yl, 'g:', 'LineWidth', 1.5); grid on;
xlabel('Seuil de decision s'); ylabel('Probabilite d''erreur');
title(sprintf('Bruit gaussien : TEB en fonction du seuil (p_1 = %.2f, \\sigma = %.2f)', p1, sg));
legend('Theorie', 'Simulation (10^6 bits)', sprintf('s* = %.3f', s_opt_g), 's = 0', 'Location', 'north');

%% 3.4 Comparaison des trois canaux (probabilites d'erreur theoriques)
sg_eq = a / sqrt(3);                        % a puissance de bruit egale : variance uniforme = a^2/3
Pe_ga = @(sg_, s) p0 * Q((s + A)/sg_) + p1 * Q((A - s)/sg_);
s_eq  = sg_eq^2 / (2*A) * log(p0 / p1);
fprintf('\n--- Comparaison des trois canaux (p1 = %.2f) ---\n', p1);
fprintf('%-34s %10s %10s\n', 'Canal', 'seuil 0', 'seuil opt');
fprintf('%-34s %10.4f %10.4f\n', sprintf('CBS (pe = %.3f)', P.pe_cbs), P.pe_cbs, P.pe_cbs);
fprintf('%-34s %10.4f %10.4f\n', sprintf('Uniforme (a = %.2f, var = %.3f)', a, a^2/3), (a - A)/(2*a), min(p0, p1)*(a - A)/a);
fprintf('%-34s %10.4f %10.4f\n', sprintf('Gaussien (sigma = %.2f, var = %.3f)', sg, sg^2), Pe_ga(sg, 0), Pe_ga(sg, s_opt_g));
fprintf('%-34s %10.4f %10.4f\n', sprintf('Gaussien meme variance (sigma = %.3f)', sg_eq), Pe_ga(sg_eq, 0), Pe_ga(sg_eq, s_eq));

%% 3.5 Chaine de base a L echantillons par bit (Matlab de reference)
%  Cette simulation sert aussi a valider le modele Simulink (section 3.6).
rng(P.graine);
L = P.L;  Tb = 1;
fprintf('\nA = %.2f, L = %d echantillons par bit, Tb = %d\n', A, L, Tb);

% variance du bruit par echantillon : Eb = A^2 Tb, N0 = Eb/(Eb/N0), sigma^2 = N0 L/(2 Tb)
EbN0_dB = 0:1:9;  EbN0 = 10.^(EbN0_dB / 10);
Eb = A^2 * Tb;  N0 = Eb ./ EbN0;  sigma2 = N0 * L / (2*Tb);

% variance apres l'integrateur : sigma^2 / L = N0/(2 Tb)
i4 = find(EbN0_dB == 4);
b  = source(2e5, 0.5);  x = A * (2*b - 1);
z  = mean(repmat(x, L, 1) + sqrt(sigma2(i4)) * randn(L, numel(b)), 1);   % sortie de l'integrateur
fprintf('Eb/N0 = 4 dB : sigma^2 = %.4f ; variance apres integration : mesure %.4f, sigma^2/L = %.4f, N0/(2Tb) = %.4f\n', ...
        sigma2(i4), var(z - x), sigma2(i4)/L, N0(i4)/(2*Tb));

% TEB en fonction de Eb/N0, avec integration (moyenne des L echantillons) et sans (un seul echantillon)
nb_bloc = 2e5;  Nmax = 1e7;  nerr_cible = 200;
teb_int = zeros(size(EbN0_dB));  teb_sans = teb_int;  err_int = teb_int;
milieu = ceil(L/2);                         % echantillon prelevé au milieu du bit
for i = 1:numel(EbN0_dB)
    sgi = sqrt(sigma2(i));  nerr = 0;  nerr_s = 0;  nbits = 0;
    while nerr < nerr_cible && nbits < Nmax
        b = source(nb_bloc, 0.5);
        R = repmat(A * (2*b - 1), L, 1) + sgi * randn(L, nb_bloc);
        nerr   = nerr   + sum((mean(R, 1)   > 0) ~= b);
        nerr_s = nerr_s + sum((R(milieu, :) > 0) ~= b);
        nbits  = nbits + nb_bloc;
    end
    teb_int(i) = nerr / nbits;  teb_sans(i) = nerr_s / nbits;  err_int(i) = nerr;
end
th_int  = Q(sqrt(2 * EbN0));                % avec integration : Q(sqrt(2 Eb/N0))
th_sans = Q(sqrt(2 * EbN0 / L));            % un seul echantillon : variance sigma^2 au lieu de sigma^2/L
fprintf('\nEb/N0 (dB)   sigma^2    TEB integ.   theorie     erreurs   TEB sans int.  theorie\n');
for i = 1:numel(EbN0_dB)
    fprintf('%6.0f     %8.4f   %9.2e   %9.2e   %7d   %10.2e   %9.2e\n', EbN0_dB(i), sigma2(i), ...
            teb_int(i), th_int(i), err_int(i), teb_sans(i), th_sans(i));
end
g_int = fzero(@(g) Q(sqrt(2*g)) - 1e-3, 5);
EbN0_1e3_dB = 10 * log10(g_int);            % Eb/N0 necessaire pour un TEB de 1e-3 (avec integration)
fprintf('\nTEB = 1e-3 : Eb/N0 = %.2f dB avec integration, %.2f dB sans (ecart %.2f dB = 10 log10(L))\n', ...
        EbN0_1e3_dB, 10*log10(g_int*L), 10*log10(L));
figure; semilogy(EbN0_dB, th_int, 'b-', 'LineWidth', 1.5); hold on;
semilogy(EbN0_dB, teb_int, 'bo', 'MarkerFaceColor', 'b'); semilogy(EbN0_dB, th_sans, 'r-', 'LineWidth', 1.5);
semilogy(EbN0_dB, teb_sans, 'rs', 'MarkerFaceColor', 'r'); grid on; ylim([1e-6 1]);
xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title(sprintf('Chaine de base : TEB en fonction de E_b/N_0 (L = %d)', L));
legend('Theorie Q(\surd(2E_b/N_0))', 'Simulation avec integration', 'Theorie sans integration', ...
       'Simulation sans integration (1 echantillon)', 'Location', 'southwest');

% complement : bruit uniforme par echantillon, avant et apres integration
N = 2e5;  b = source(N, 0.5);  x = A * (2*b - 1);
Ru = repmat(x, L, 1) + a * (2*rand(L, N) - 1);
zu = mean(Ru, 1);  bruit = zu - x;          % bruit apres integration
fprintf('\n--- Bruit uniforme (a = %.2f) ---\n', a);
fprintf('Variance apres integration : %.4f (theorie a^2/(3L) = %.4f)\n', var(bruit), a^2/(3*L));
fprintf('Valeur absolue max du bruit apres integration : %.3f (borne a = %.2f)\n', max(abs(bruit)), a);
fprintf('TEB seuil nul, sans integration : %.4f (theorie (a-A)/(2a) = %.4f)\n', mean((Ru(milieu, :) > 0) ~= b), (a - A)/(2*a));
fprintf('TEB seuil nul, avec integration : %.4f\n', mean((zu > 0) ~= b));
figure; histogram(bruit, 60, 'Normalization', 'pdf'); hold on;
v = a^2 / (3*L);  t = linspace(-a, a, 400);
plot(t, exp(-t.^2 / (2*v)) / sqrt(2*pi*v), 'r', 'LineWidth', 1.5);
plot([-a -a a a], [0 1/(2*a) 1/(2*a) 0], 'k--', 'LineWidth', 1.5); grid on;
xlabel('Bruit'); ylabel('Densite'); title(sprintf('Bruit uniforme (a = %.2f) apres integration sur L = %d echantillons', a, L));
legend('Histogramme apres integration', 'Gaussienne de meme variance', 'Densite avant integration', 'Location', 'north');

%% 3.6 (facultatif) Modele Simulink chaine_base : TEB en fonction de Eb/N0
%  Active avec utiliser_simulink = true (section 0). Le modele lit dans l'espace de travail :
%  A, L, Tb, Te, graine, p1_chaine, seuil, sigma2, Nbits ; il enregistre b_tx, b_rx, b_rx_sans.
if utiliser_simulink && exist('chaine_base.slx', 'file')
    Te = Tb / L;  graine = P.graine;  p1_chaine = 0.5;  seuil = 0;  Nbits = 1000;
    modele = 'chaine_base';  load_system(modele);

    sigma2 = 0;  set_param(modele, 'StopTime', '1000');          % retard mesure sans bruit
    out = sim(modele);
    btx = out.b_tx(:);  brx = out.b_rx(:);  n = min(numel(btx), numel(brx));  btx = btx(1:n);  brx = brx(1:n);
    nerr_d = arrayfun(@(d) sum(brx(d+1:end) ~= btx(1:end-d)), 0:3);
    [~, id] = min(nerr_d);  retard_sl = id - 1;
    fprintf('\nSimulink : retard de la chaine = %d bit(s)\n', retard_sl);

    Nmax_sl = 2e6;  teb_sl = zeros(size(EbN0_dB));  teb_sl_sans = teb_sl;
    for i = 1:numel(EbN0_dB)
        sigma2 = (A^2 * Tb / EbN0(i)) * L / (2*Tb);
        Nb = min(max(2e4, ceil(200 / th_int(i))), Nmax_sl);
        set_param(modele, 'StopTime', num2str(Nb * Tb));
        out = sim(modele);
        btx = out.b_tx(:);  brx = out.b_rx(:);  brs = out.b_rx_sans(:);
        n = min([numel(btx), numel(brx), numel(brs)]);  btx = btx(1:n);  brx = brx(1:n);  brs = brs(1:n);
        teb_sl(i)      = mean(brx(retard_sl+1:end) ~= btx(1:end-retard_sl));
        teb_sl_sans(i) = mean(brs(retard_sl+1:end) ~= btx(1:end-retard_sl));
        fprintf('Eb/N0 = %d dB : TEB Simulink = %.2e (theorie %.2e)\n', EbN0_dB(i), teb_sl(i), th_int(i));
    end
    figure; semilogy(EbN0_dB, th_int, 'b-', 'LineWidth', 1.5); hold on;
    semilogy(EbN0_dB, max(teb_sl, 1e-7), 'bo', 'MarkerFaceColor', 'b');
    semilogy(EbN0_dB, th_sans, 'r-', 'LineWidth', 1.5); semilogy(EbN0_dB, teb_sl_sans, 'rs', 'MarkerFaceColor', 'r');
    grid on; ylim([1e-6 1]); xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title(sprintf('Simulink : TEB de la chaine de base (L = %d)', L));
    legend('Theorie avec integration', 'Simulink avec integration', 'Theorie sans integration', 'Simulink sans integration', 'Location', 'southwest');
end


%% ========================================================================
%  PARTIE 4 : CODAGE DE CANAL, CODE DE HAMMING (7,4)
%% ========================================================================

%% 4.1 Construction et validation du code (g(x) = 1 + x + x^3, forme systematique c = [m | r])
% Restes de la division x^3 m(x) par g(x) pour les 4 messages de poids 1
fprintf('\nRestes x^3 m(x) mod g(x) :\n');
Pm = zeros(4, 3);
for i = 1:4
    m = zeros(1, 4);  m(i) = 1;
    Pm(i, :) = reste_g(m);
    fprintf('  m = %s  ->  r = %s\n', mat2str(m), mat2str(Pm(i, :)));
end
Gm = [eye(4), Pm];                          % generatrice systematique
Hm = [Pm.', eye(3)];                        % matrice de controle
disp('Matrice generatrice G = [I4 | P] :');  disp(Gm);
disp('Matrice de controle H = [P^T | I3] :'); disp(Hm);
fprintf('G*H^T = 0 (modulo 2) ? %d\n', ~any(any(mod(Gm * Hm.', 2))));
[G2, H2] = hamming_GH();
fprintf('Concordance avec hamming_GH.m ? %d\n', isequal(Gm, G2) && isequal(Hm, H2));

% colonnes de H, distance minimale
fprintf('\nColonnes de H toutes non nulles ? %d\n', all(any(Hm, 1)));
fprintf('Nombre de colonnes distinctes : %d sur 7\n', size(unique(Hm.', 'rows'), 1));
Mm = dec2bin(0:15) - '0';                   % les 16 messages
Cm = hamming_encode(Mm);                    % les 16 mots-code
poids = sum(Cm, 2);
dmin = min(poids(poids > 0));
fprintf('Distance minimale du code : %d\n', dmin);
fprintf('Nombre de mots-code de poids 0 a 7 : %s\n', mat2str(accumarray(poids + 1, 1).'));
fprintf('Le code detecte %d erreurs et en corrige %d\n', dmin - 1, floor((dmin - 1) / 2));
fprintf('Code parfait ? 2^k (1 + n) = %d = 2^n = %d : %d\n', 16*8, 2^7, 16*8 == 2^7);
Cpoly = zeros(16, 7);                       % le codage par division polynomiale redonne le codage matriciel
for i = 1:16, Cpoly(i, :) = [Mm(i, :), reste_g(Mm(i, :))]; end
fprintf('Codage par reste de division == codage matriciel ? %d\n', isequal(Cpoly, Cm));

% validation du codeur et du decodeur
fprintf('\nSans erreur : %d messages sur 16 restitues\n', sum(all(hamming_decode(Cm) == Mm, 2)));
ok = zeros(1, 7);
for j = 1:7
    Rj = Cm;  Rj(:, j) = 1 - Rj(:, j);     % une erreur en position j, pour les 16 mots
    ok(j) = sum(all(hamming_decode(Rj) == Mm, 2));
end
fprintf('Une erreur en position 1..7 : messages corriges sur 16 = %s\n', mat2str(ok));

c0 = hamming_encode([1 0 1 1]);             % le syndrome d'une erreur simple est la colonne de H correspondante
S = zeros(7, 3);
for j = 1:7
    rj = c0;  rj(j) = 1 - rj(j);
    [~, ~, S(j, :)] = hamming_decode(rj);
end
disp('Syndrome en fonction de la position j de l''erreur :');  disp([(1:7).', S]);
fprintf('Syndromes == colonnes de H ? %d\n', isequal(S, Hm.'));

paires = nchoosek(1:7, 2);                  % deux erreurs : le decodeur "corrige" a tort
nb_faux = 0;  nb_bits_faux = 0;
for k = 1:size(paires, 1)
    Rk = Cm;
    Rk(:, paires(k, 1)) = 1 - Rk(:, paires(k, 1));
    Rk(:, paires(k, 2)) = 1 - Rk(:, paires(k, 2));
    mh = hamming_decode(Rk);
    nb_faux = nb_faux + sum(any(mh ~= Mm, 2));
    nb_bits_faux = nb_bits_faux + sum(sum(mh ~= Mm));
end
nb_tot = 16 * size(paires, 1);
fprintf('\nDeux erreurs : %d messages faux sur %d ; %.2f bits d''information faux en moyenne par mot\n', ...
        nb_faux, nb_tot, nb_bits_faux / nb_tot);

%% 4.2 Performances du code : blocs faux, approximation de Pb, TEB avec et sans codage
rng(1);
% Q7 : probabilite de bloc faux
pq = logspace(-4, -0.3, 200);
Pfaux_sans = 1 - (1 - pq).^4;                                % bloc de 4 bits sans codage
Pfaux_avec = 1 - ((1 - pq).^7 + 7*pq.*(1 - pq).^6);          % mot de 7 bits : 0 ou 1 erreur corrigee
figure; loglog(pq, Pfaux_sans, 'b-', pq, Pfaux_avec, 'r-'); grid on;
xlabel('p (probabilite d''erreur sur un bit)'); ylabel('Probabilite de bloc faux');
legend('4 bits sans codage', 'mot de 7 bits avec codage', 'Location', 'northwest');
title('Probabilite de bloc faux, avec et sans codage');

% Q8 : approximation du sujet (j/7) comparee a la valeur exacte (enumeration des 128 erreurs)
pp8 = logspace(-3, -1, 50);
figure; loglog(pp8, pb_hamming(pp8, 'approx'), 'b--', pp8, pb_hamming(pp8, 'exact'), 'r-'); grid on;
xlabel('p'); ylabel('P_b apres correction');
legend('approximation du sujet (j/7)', 'valeur exacte (enumeration des 128 erreurs)', 'Location', 'northwest');
title('L''approximation est optimiste');
fprintf('\nRapport exact/approx a p = 1e-3 : %.2f (tend vers 3/2 pour p -> 0)\n', pb_hamming(1e-3, 'exact') / pb_hamming(1e-3, 'approx'));

% Q9-Q10 : TEB theorique et simule (A = 1, Tb = 1, Eb = 1, bruit apres integration de variance 1/(2 Eb/N0))
x_th = -2:0.1:9;  g_th = 10.^(x_th / 10);
Pb_nc_th = Q(sqrt(2 * g_th));                                % sans codage
p_th     = Q(sqrt(2 * (4/7) * g_th));                        % bit code : Ec = 4/7 Eb
Pb_c_ap  = pb_hamming(p_th, 'approx');
Pb_c_ex  = pb_hamming(p_th, 'exact');

EbN0dB = 0:9;  nb_err_min = 100;  Nmax = 2e7;  Nw = 2e5;
TEB_nc = zeros(size(EbN0dB));  N_nc = TEB_nc;  TEB_c = TEB_nc;  N_c = TEB_nc;
for k = 1:numel(EbN0dB)
    sgm = sqrt(1 / (2 * 10^(EbN0dB(k) / 10)));
    err = 0;  nb = 0;                                        % sans codage
    while err < nb_err_min && nb < Nmax
        bk = double(rand(4*Nw, 1) > 0.5);
        rk = (2*bk - 1) + sgm * randn(size(bk));
        err = err + sum(double(rk > 0) ~= bk);  nb = nb + numel(bk);
    end
    TEB_nc(k) = err / nb;  N_nc(k) = nb;
    err = 0;  nb = 0;                                        % avec Hamming (7,4)
    while err < nb_err_min && nb < Nmax
        mk = double(rand(Nw, 4) > 0.5);
        ck = hamming_encode(mk);
        rk = sqrt(4/7) * (2*ck - 1) + sgm * randn(size(ck)); % amplitude d'un bit code : sqrt(4/7)
        mh = hamming_decode(double(rk > 0));
        err = err + sum(mh(:) ~= mk(:));  nb = nb + numel(mk);
    end
    TEB_c(k) = err / nb;  N_c(k) = nb;
end
IC_nc = 1.96 * sqrt(TEB_nc .* (1 - TEB_nc) ./ N_nc);         % intervalles de confiance a 95 %
IC_c  = 1.96 * sqrt(TEB_c  .* (1 - TEB_c ) ./ N_c );
fprintf('\nEb/N0(dB) | TEB sans codage (+-IC95) | TEB avec codage (+-IC95)\n');
for k = 1:numel(EbN0dB)
    fprintf('%6d    | %.3e (+-%.1e)    | %.3e (+-%.1e)\n', EbN0dB(k), TEB_nc(k), IC_nc(k), TEB_c(k), IC_c(k));
end
figure; semilogy(x_th, Pb_nc_th, 'b-', x_th, Pb_c_ap, 'r--', x_th, Pb_c_ex, 'r-'); hold on;
errorbar(EbN0dB, TEB_nc, IC_nc, 'bo'); errorbar(EbN0dB, TEB_c, IC_c, 'rs');
plot([0.24 0.24], [1e-6 1], 'k--'); plot([-1.59 -1.59], [1e-6 1], 'k:');   % limites de Shannon
grid on; xlim([-2 9]); ylim([1e-6 1]); xlabel('E_b/N_0 (dB)'); ylabel('TEB');
legend('sans codage (theorie)', 'Hamming (approx. du sujet)', 'Hamming (exact)', 'sans codage (simulation)', ...
       'Hamming (simulation)', 'Shannon R = 4/7 : 0,24 dB', 'limite absolue : -1,59 dB', 'Location', 'southwest');
title('TEB avec et sans codage de Hamming (7,4), canal gaussien');

% Q11 : seuil d'avantage et gain de codage
f_nc = @(x) Q(sqrt(2 * 10^(x/10)));
f_c  = @(x) pb_hamming(Q(sqrt(2 * (4/7) * 10^(x/10))), 'exact');
x_croise = fzero(@(x) f_c(x) - f_nc(x), [1 9]);
x_nc = fzero(@(x) f_nc(x) - 1e-4, [5 12]);
x_c  = fzero(@(x) f_c(x)  - 1e-4, [5 12]);
gain_codage = x_nc - x_c;
fprintf('\nLe codage devient avantageux a partir de Eb/N0 = %.2f dB\n', x_croise);
fprintf('Eb/N0 pour TEB = 1e-4 : sans codage %.2f dB, avec codage %.2f dB -> gain de codage = %.2f dB\n', x_nc, x_c, gain_codage);
fprintf('Ecart a la limite de Shannon (R = 4/7, 0,24 dB) a 1e-4 : %.2f dB\n', x_c - 0.24);


%% ========================================================================
%  PARTIE 5 : MODULATION QPSK
%  Symbole e^{j k pi/4}, k dans {1,3,5,7}, enveloppe complexe, Es = 1 (Eb = 1/2).
%  Chaque voie (I, Q) porte un bit d'amplitude 1/sqrt(2).
%% ========================================================================

%% 5. QPSK : mapping de Gray / naturel, constellations, TEB, QPSK + Hamming
rng(P.graine);
sa = 1 / sqrt(2);                           % amplitude par voie
% Gray : 00 -> k=1, 01 -> k=7, 11 -> k=5, 10 -> k=3 (I porte b1, Q porte b2)
mod_gray = @(b1, b2) sa * (1 - 2*b1) + 1j * sa * (1 - 2*b2);
dem_gray = @(z) deal(double(real(z) < 0), double(imag(z) < 0));
% naturel : 00 -> k=1, 01 -> k=3, 10 -> k=5, 11 -> k=7
mod_nat  = @(b1, b2) sa * (1 - 2*xor(b1, b2)) + 1j * sa * (1 - 2*b1);
dem_nat  = @(z) deal(double(imag(z) < 0), double(xor(real(z) < 0, imag(z) < 0)));

% Q1 : mapping et energie par bit
fprintf('\nQ1 : Es = 1 -> Eb = Es/2 = %.2f ; bits -> k (phase k*pi/4), Gray\n', 1/2);
for bq = [0 0; 0 1; 1 1; 1 0].'
    zq = mod_gray(bq(1), bq(2));
    fprintf('  %d%d -> k = %d  (symbole %+.3f %+.3fj)\n', bq(1), bq(2), mod(round(angle(zq) / (pi/4)), 8), real(zq), imag(zq));
end

% Q2 : validation sans bruit
bq = double(rand(2, 1e5) < 0.5);
[h1, h2] = dem_gray(mod_gray(bq(1, :), bq(2, :)));
fprintf('Q2 : sans bruit, Gray : %d erreurs sur %d bits\n', sum([h1 h2] ~= [bq(1, :) bq(2, :)]), 2e5);
[h1, h2] = dem_nat(mod_nat(bq(1, :), bq(2, :)));
fprintf('     sans bruit, naturel : %d erreurs sur %d bits\n', sum([h1 h2] ~= [bq(1, :) bq(2, :)]), 2e5);

% Q3 : constellations recues a 0, 5 et 10 dB
figure;
for i = 1:3
    gdbc = [0 5 10];  sgc = sqrt(0.25 / 10^(gdbc(i)/10));   % N0 = Eb/g = 0.5/g, variance par voie N0/2
    bb = double(rand(2, 3000) < 0.5);
    zc = mod_gray(bb(1, :), bb(2, :)) + sgc * (randn(1, 3000) + 1j * randn(1, 3000));
    subplot(1, 3, i); plot(real(zc), imag(zc), '.', 'MarkerSize', 4); hold on;
    plot([-sa sa sa -sa], [sa sa -sa -sa], 'r+', 'MarkerSize', 12, 'LineWidth', 2);
    plot([-2 2], [0 0], 'k:'); plot([0 0], [-2 2], 'k:'); axis equal; axis([-2 2 -2 2]); grid on;
    xlabel('I'); ylabel('Q'); title(sprintf('E_b/N_0 = %d dB', gdbc(i)));
end

% Q4-Q5 : TEB, Gray et mapping naturel
EbN0_dB = 0:1:9;  EbN0 = 10.^(EbN0_dB / 10);
p_voie = Q(sqrt(2 * EbN0));                 % probabilite d'erreur par voie
teb_gray_th = p_voie;                       % = TEB de la chaine binaire de la partie 3
teb_nat_th  = (3*p_voie - 2*p_voie.^2) / 2; % naturel : b1 faux = 1 voie, b2 faux = 1 voie sur 2
teb_g = zeros(size(EbN0));  teb_n = teb_g;  nerr_g = teb_g;
chunk = 1e6;  Nmax = 2e7;  ncible = 200;
for i = 1:numel(EbN0)
    sgc = sqrt(0.25 / EbN0(i));  eg = 0;  en = 0;  nb = 0;
    while (eg < ncible || en < ncible) && nb < Nmax
        bb = double(rand(2, chunk) < 0.5);
        nz = sgc * (randn(1, chunk) + 1j * randn(1, chunk));
        [h1, h2] = dem_gray(mod_gray(bb(1, :), bb(2, :)) + nz);
        eg = eg + sum(h1 ~= bb(1, :)) + sum(h2 ~= bb(2, :));
        [h1, h2] = dem_nat(mod_nat(bb(1, :), bb(2, :)) + nz);
        en = en + sum(h1 ~= bb(1, :)) + sum(h2 ~= bb(2, :));
        nb = nb + 2*chunk;
    end
    teb_g(i) = eg / nb;  teb_n(i) = en / nb;  nerr_g(i) = eg;
end
fprintf('\nEb/N0 (dB) | Gray sim / theorie  | naturel sim / theorie | rapport nat/Gray | erreurs Gray\n');
for i = 1:numel(EbN0)
    fprintf('%6d     | %.2e / %.2e | %.2e / %.2e   | %.2f             | %d\n', EbN0_dB(i), ...
            teb_g(i), teb_gray_th(i), teb_n(i), teb_nat_th(i), teb_n(i) / teb_g(i), nerr_g(i));
end
figure; semilogy(EbN0_dB, teb_gray_th, 'b-', 'LineWidth', 1.5); hold on;
semilogy(EbN0_dB, teb_g, 'bo', 'MarkerFaceColor', 'b'); semilogy(EbN0_dB, teb_nat_th, 'r-', 'LineWidth', 1.5);
semilogy(EbN0_dB, teb_n, 'rs', 'MarkerFaceColor', 'r'); grid on; ylim([1e-6 1]);
xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title('QPSK : TEB avec mapping de Gray et mapping naturel');
legend('Gray : Q(\surd(2E_b/N_0))', 'Gray (simulation)', 'Naturel : (3p - 2p^2)/2', 'Naturel (simulation)', 'Location', 'southwest');

% Q6 : QPSK avec Hamming (7,4). Mots-codes mis bout a bout puis regroupes deux par deux
% (nombre PAIR de mots : 7 symboles pour 2 mots, aucun bourrage). Ec = Es/2 = 0.5, Eb = 0.875.
Nw = 2e5;  Nmax_w = 2e7;
teb_hq = zeros(size(EbN0));  nerr_hq = teb_hq;
teb_hq_th = pb_hamming(Q(sqrt(2 * (4/7) * EbN0)), 'exact');   % courbe exacte de la partie 4
for i = 1:numel(EbN0)
    sgc = sqrt(0.4375 / EbN0(i));           % N0 = Eb/g = 0.875/g, variance par voie N0/2
    e = 0;  nb = 0;
    while e < ncible && nb < Nmax_w
        mk = double(rand(Nw, 4) < 0.5);
        cs = reshape(hamming_encode(mk).', 2, []);            % flux serie regroupe par paires
        zc = mod_gray(cs(1, :), cs(2, :)) + sgc * (randn(1, size(cs, 2)) + 1j * randn(1, size(cs, 2)));
        [h1, h2] = dem_gray(zc);
        mh = hamming_decode(reshape([h1; h2], 7, []).');      % retour aux mots de 7 bits
        e = e + sum(sum(mh ~= mk));  nb = nb + 4*Nw;
    end
    teb_hq(i) = e / nb;  nerr_hq(i) = e;
end
fprintf('\nEb/N0 | QPSK+Hamming sim | theorie exacte partie 4 | QPSK sans codage (theorie) | erreurs\n');
for i = 1:numel(EbN0)
    fprintf('%4d  |   %.2e       |      %.2e           |        %.2e            | %d\n', ...
            EbN0_dB(i), teb_hq(i), teb_hq_th(i), teb_gray_th(i), nerr_hq(i));
end
figure; semilogy(EbN0_dB, teb_gray_th, 'b-', 'LineWidth', 1.5); hold on;
semilogy(EbN0_dB, teb_hq_th, 'r-', 'LineWidth', 1.5); semilogy(EbN0_dB, teb_g, 'bo', 'MarkerFaceColor', 'b');
semilogy(EbN0_dB, teb_hq, 'rs', 'MarkerFaceColor', 'r'); grid on; ylim([1e-6 1]);
xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title('QPSK avec et sans codage de Hamming (7,4)');
legend('Sans codage (theorie)', 'Hamming, partie 4 (theorie exacte)', 'QPSK sans codage (simulation)', ...
       'QPSK + Hamming (simulation)', 'Location', 'southwest');


%% ========================================================================
%  PARTIE 6 : FILTRE DE MISE EN FORME ET FILTRE ADAPTE
%  Representation sur-echantillonnee : L echantillons par symbole, T = 1, filtres d'energie unite.
%% ========================================================================

%% 6. Filtre porte et racine de cosinus sureleve (RRC)
rng(P.graine);
L = P.L;  alpha = P.alpha;  span = 10;
a0 = 1 / sqrt(2);
hr = ones(1, L) / sqrt(L);                  % filtre porte, energie unite
hc = rrc_coeffs(alpha, L, span);            % racine de cosinus sureleve
N  = numel(hc);
fprintf('\nL = %d echantillons par symbole, alpha = %.2f, span = %d symboles\n', L, alpha, span);
fprintf('N = %d coefficients, retard de la chaine = N-1 = %d echantillons = %d symboles\n', N, N-1, span);

% chaine complete d'une voie : mise en forme, bruit de variance sg^2, filtre adapte
chaine = @(h, a, sg) filter(fliplr(h), 1, filter(h, 1, [kron(a, [1 zeros(1, L-1)]) zeros(1, numel(h)-1)]) ...
                                         + sg * randn(1, numel(a)*L + numel(h) - 1));

% Q1 : filtre porte = detecteur optimal de la figure 3, le TEB est inchange
gdb = 0:2:8;  th6 = Q(sqrt(2 * 10.^(gdb / 10)));
teb_r = zeros(size(gdb));  nerr_r = teb_r;
for i = 1:numel(gdb), [teb_r(i), nerr_r(i)] = teb_chaine_filtree(hr, L, gdb(i), 0, 150, 5e6); end
fprintf('\nQ1 : filtre porte, TEB simule / theorique :\n');
for i = 1:numel(gdb), fprintf('  %d dB : %.2e / %.2e  (%d erreurs)\n', gdb(i), teb_r(i), th6(i), nerr_r(i)); end

% Q2 : limites de h en 0 et en +-T/(4 alpha), comparaison avec rcosdesign si disponible
t0 = 1 / (4*alpha);
gen = @(t) (4*alpha/pi * cos(pi*(1+alpha)*t) + (1-alpha) * sin(pi*(1-alpha)*t) ./ (pi*(1-alpha)*t)) ./ (1 - (4*alpha*t).^2);
fprintf('\nQ2 : alpha = %.2f\n', alpha);
fprintf('  h(0)      : formule %.6f | formule generale en t = 1e-6 : %.6f\n', 1 - alpha + 4*alpha/pi, gen(1e-6));
fprintf('  h(T/(4a)) : formule %.6f | formule generale en t = T/(4a)+1e-6 : %.6f\n', ...
        alpha/sqrt(2) * ((1 + 2/pi) * sin(pi/(4*alpha)) + (1 - 2/pi) * cos(pi/(4*alpha))), gen(t0 + 1e-6));
if exist('rcosdesign', 'file')
    h2 = rcosdesign(alpha, span, L, 'sqrt');  h2 = h2 / norm(h2);
    fprintf('  Ecart maximal avec rcosdesign : %.2e\n', max(abs(h2 - hc)));
else
    disp('  rcosdesign non disponible (Communications Toolbox) : comparaison non effectuee');
end

% Q3 : h et h*h, interference entre symboles aux multiples de T
tt = (-(N-1)/2 : (N-1)/2) / L;
hh = conv(hc, hc);  th2 = (-(N-1) : (N-1)) / L;
c0 = (N + 1) / 2;  cg = N;                  % indices des centres de h et de h*h
k = 1:span-1;  kh = 1:span/2;
fprintf('\nQ3 : valeurs aux multiples non nuls de T, relatives a la valeur en 0\n');
fprintf('  |h(kT)/h(0)|, k = 1..3 : %s\n', mat2str(abs(hc(c0 + (1:3)*L) / hc(c0)), 3));
ies = max(abs(hh(cg + k*L) / hh(cg)));
fprintf('  max |(h*h)(kT)/(h*h)(0)|, k = 1..%d : %.2e (%.1f dB)\n', span-1, ies, 20*log10(ies));
figure;
subplot(2, 1, 1); stem(tt, hc, 'b.'); hold on; plot(kh, hc(c0 + kh*L), 'ro'); plot(-kh, hc(c0 - kh*L), 'ro'); grid on;
xlabel('t / T'); ylabel('h(t)'); title(sprintf('RRC, \\alpha = %.2f (cercles rouges : t = kT)', alpha));
subplot(2, 1, 2); plot(th2, hh, 'b'); hold on; plot(k, hh(cg + k*L), 'ro'); plot(-k, hh(cg - k*L), 'ro'); grid on;
xlabel('t / T'); ylabel('(h*h)(t)'); title('h*h : nul aux multiples non nuls de T (critere de Nyquist)');

% Q4 : densites spectrales de puissance du signal emis
M6 = 2e5;  a_ = sign(randn(1, M6));  xup = zeros(1, M6*L);  xup(1:L:end) = a_;
sr = filter(hr, 1, xup);  sc = filter(hc, 1, xup);
[Pr, f] = pwelch(sr, hann(1024), 512, 1024, L);        % fs = L : f en unites de 1/T
Pc = pwelch(sc, hann(1024), 512, 1024, L);
Bth = (1 + alpha) / 2;                                  % bande theorique unilaterale (1+alpha)/(2T)
frac = @(Pw) sum(Pw(f <= Bth)) / sum(Pw);
b99  = @(Pw) f(find(cumsum(Pw) / sum(Pw) >= 0.99, 1));
B99_porte = b99(Pr);  B99_rrc = b99(Pc);
fprintf('\nQ4 : bande theorique (1+alpha)/(2T) = %.3f /T\n', Bth);
fprintf('  porte : %.1f %% de la puissance dans la bande theorique, B99 = %.2f /T\n', 100*frac(Pr), B99_porte);
fprintf('  RRC   : %.2f %% de la puissance dans la bande theorique, B99 = %.2f /T\n', 100*frac(Pc), B99_rrc);
figure; plot(f, 10*log10(Pr / max(Pr)), 'r', 'LineWidth', 1.2); hold on;
plot(f, 10*log10(Pc / max(Pc)), 'b', 'LineWidth', 1.5); plot([Bth Bth], [-100 5], 'k--');
grid on; ylim([-80 5]); xlabel('f T'); ylabel('DSP normalisee (dB)'); title('DSP du signal emis : filtre porte et RRC');
legend('Porte', sprintf('RRC \\alpha = %.2f', alpha), sprintf('(1+\\alpha)/(2T) = %.2f', Bth));

% Q5 : constellations, diagramme de l'oeil, TEB (une voie = TEB de la chaine QPSK en Gray)
ns = 3000;  sg10 = sqrt(0.25 / 10);                     % Eb/N0 = 10 dB
filtres = {hr, hc};  nomf = {'Porte', sprintf('RRC \\alpha = %.2f', alpha)};
figure;
for q = 1:2
    h = filtres{q};
    aI = a0 * (1 - 2*(rand(1, ns) < 0.5));  aQ = a0 * (1 - 2*(rand(1, ns) < 0.5));
    zI = chaine(h, aI, sg10);  zQ = chaine(h, aQ, sg10);
    idx = ((1:ns) - 1) * L + numel(h);
    subplot(1, 2, q); plot(zI(idx), zQ(idx), '.', 'MarkerSize', 4); hold on;
    plot([-a0 a0 a0 -a0], [a0 a0 -a0 -a0], 'r+', 'MarkerSize', 12, 'LineWidth', 2);
    axis equal; axis([-1.5 1.5 -1.5 1.5]); grid on; xlabel('I'); ylabel('Q'); title([nomf{q} ', 10 dB']);
end
figure;
for q = 1:2
    a_ = a0 * (1 - 2*(rand(1, 400) < 0.5));
    subplot(2, 2, q);   oeil(chaine(filtres{q}, a_, 0),    numel(filtres{q}), L, 200); title([nomf{q} ', sans bruit']);
    subplot(2, 2, q+2); oeil(chaine(filtres{q}, a_, sg10), numel(filtres{q}), L, 200); title([nomf{q} ', 10 dB']);
end
teb_c6 = zeros(size(gdb));  nerr_c6 = teb_c6;
for i = 1:numel(gdb), [teb_c6(i), nerr_c6(i)] = teb_chaine_filtree(hc, L, gdb(i), 0, 150, 5e6); end
fprintf('\nQ5 : TEB (une voie)\nEb/N0 | theorie    | porte      | RRC (alpha = %.2f)\n', alpha);
for i = 1:numel(gdb)
    fprintf('%4d  | %.2e   | %.2e   | %.2e (%d erreurs)\n', gdb(i), th6(i), teb_r(i), teb_c6(i), nerr_c6(i));
end
figure; semilogy(gdb, th6, 'k-', 'LineWidth', 1.5); hold on;
semilogy(gdb, teb_r, 'rs', 'MarkerFaceColor', 'r'); semilogy(gdb, teb_c6, 'bo', 'MarkerFaceColor', 'b'); grid on;
xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title('Chaine filtree : TEB avec filtres porte et RRC');
legend('Theorie Q(\surd(2E_b/N_0))', 'Filtres porte', sprintf('Filtres RRC (\\alpha = %.2f)', alpha), 'Location', 'southwest');

% Q6 : decalage de l'instant d'echantillonnage (alpha personnel et alpha = 1)
alphas = [alpha 1];  off = 0:L/2;  g6 = 8;
teb_off = zeros(numel(alphas), numel(off));
for ia = 1:numel(alphas)
    h = rrc_coeffs(alphas(ia), L, span);
    for io = 1:numel(off), teb_off(ia, io) = teb_chaine_filtree(h, L, g6, off(io), 100, 3e6); end
end
fprintf('\nQ6 : TEB a Eb/N0 = %d dB en fonction du decalage de l''instant d''echantillonnage\n', g6);
fprintf('decalage (en T) : %s\n', mat2str(off / L, 3));
for ia = 1:numel(alphas), fprintf('alpha = %.2f : %s\n', alphas(ia), sprintf('%.2e  ', teb_off(ia, :))); end
fprintf('theorie sans decalage : %.2e\n', Q(sqrt(2 * 10^(g6/10))));
figure; semilogy(off / L, teb_off(1, :), 'bo-', 'LineWidth', 1.5, 'MarkerFaceColor', 'b'); hold on;
semilogy(off / L, teb_off(2, :), 'rs-', 'LineWidth', 1.5, 'MarkerFaceColor', 'r'); grid on;
xlabel('Decalage de l''instant d''echantillonnage / T'); ylabel('TEB');
title(sprintf('Sensibilite au decalage de l''echantillonnage (E_b/N_0 = %d dB)', g6));
legend(sprintf('\\alpha = %.2f', alphas(1)), '\alpha = 1', 'Location', 'southeast');
figure; dec = L / 4;                        % decalage de T/4
for ia = 1:2
    h = rrc_coeffs(alphas(ia), L, span);
    a_ = a0 * (1 - 2*(rand(1, 400) < 0.5));
    subplot(2, 2, ia); oeil(chaine(h, a_, 0), numel(h), L, 200, dec);
    title(sprintf('Oeil, \\alpha = %.2f (rouge : decalage T/4)', alphas(ia)));
    aI = a0 * (1 - 2*(rand(1, ns) < 0.5));  aQ = a0 * (1 - 2*(rand(1, ns) < 0.5));
    zI = chaine(h, aI, sg10);  zQ = chaine(h, aQ, sg10);
    idx = ((1:ns) - 1) * L + numel(h) + dec;
    subplot(2, 2, ia + 2); plot(zI(idx), zQ(idx), '.', 'MarkerSize', 4); hold on;
    plot([-a0 a0 a0 -a0], [a0 a0 -a0 -a0], 'r+', 'MarkerSize', 12, 'LineWidth', 2);
    axis equal; axis([-1.5 1.5 -1.5 1.5]); grid on; xlabel('I'); ylabel('Q');
    title(sprintf('Constellation, \\alpha = %.2f, decalage T/4, 10 dB', alphas(ia)));
end


%% ========================================================================
%  PARTIE 7 : COMPLEMENT - CANAL A ECHO hc(t) = delta(t) + beta delta(t - tau T)
%% ========================================================================

%% 7. Canal a echo : Nyquist, oeil, TEB, egaliseurs (ZF et DFE), transmission d'un texte
rng(P.graine);
beta = P.beta;  tau = P.retard_trajet;
h = rrc_coeffs(alpha, L, span);  N = numel(h);
fprintf('\nalpha = %.2f, beta = %.2f, tau = %d T, L = %d\n', alpha, beta, tau, L);

% Q1 : le critere de Nyquist n'est plus verifie
pn = conv(h, h);                                        % h*h : Nyquist
pc = [pn zeros(1, tau*L)] + beta * [zeros(1, tau*L) pn];% reponse globale avec echo
fprintf('Q1 : reponse globale aux instants kT, centre en 0\n');
for kk = -2 : tau + 2, fprintf('  k = %2d : %+.4f\n', kk, pc(N + kk*L)); end
fprintf('  -> un terme egal a beta = %.2f apparait en k = %d : Nyquist n''est plus verifie.\n', beta, tau);

gdb = 0:2:8;  g7 = 10.^(gdb / 10);
th_sans = Q(sqrt(2*g7));
th_brut = 0.5 * Q(sqrt(2*g7) * (1 + beta)) + 0.5 * Q(sqrt(2*g7) * (1 - beta));   % echo, sans egaliseur
th_zf   = Q(sqrt(2*g7 * (1 - beta^2)));                                          % zero-forcing
teb_b = zeros(size(gdb));  teb_z = teb_b;  teb_d = teb_b;  teb_0 = teb_b;
for i = 1:numel(gdb)
    teb_0(i) = teb_canal_echo(h, L, gdb(i), 0,    tau, 'brut', 150, 5e6);
    teb_b(i) = teb_canal_echo(h, L, gdb(i), beta, tau, 'brut', 150, 5e6);
    teb_z(i) = teb_canal_echo(h, L, gdb(i), beta, tau, 'zf',   150, 5e6);
    teb_d(i) = teb_canal_echo(h, L, gdb(i), beta, tau, 'dfe',  100, 2e6);
end
fprintf('\nTEB, canal a echo (beta = %.2f, tau = %d T)\n', beta, tau);
fprintf('Eb/N0 | sans echo (th) | sans echo (sim) | echo brut th / sim | ZF th / sim | DFE sim\n');
for i = 1:numel(gdb)
    fprintf('%4d  | %.2e       | %.2e        | %.2e / %.2e | %.2e / %.2e | %.2e\n', gdb(i), th_sans(i), teb_0(i), ...
            th_brut(i), teb_b(i), th_zf(i), teb_z(i), teb_d(i));
end

% diagramme de l'oeil avec echo, sans bruit puis a 10 dB
a_ = a0 * (1 - 2*(rand(1, 400) < 0.5));
zoeil = cell(1, 2);
for q = 1:2
    sgq = (q == 2) * sqrt(0.25 / 10);
    s7  = filter(h, 1, [kron(a_, [1 zeros(1, L-1)]) zeros(1, N-1)]);
    s7  = s7 + beta * [zeros(1, tau*L) s7(1:end - tau*L)];
    zoeil{q} = filter(fliplr(h), 1, s7 + sgq * randn(size(s7)));
end
figure;
subplot(1, 2, 1); oeil(zoeil{1}, N, L, 200); title(sprintf('Oeil avec echo (\\beta = %.2f, \\tau = %dT), sans bruit', beta, tau));
subplot(1, 2, 2); oeil(zoeil{2}, N, L, 200); title('Oeil avec echo, 10 dB');
figure; semilogy(gdb, th_sans, 'k-', 'LineWidth', 1.5); hold on;
semilogy(gdb, th_brut, 'r-', 'LineWidth', 1.5); semilogy(gdb, teb_b, 'ro', 'MarkerFaceColor', 'r');
semilogy(gdb, th_zf, 'g-', 'LineWidth', 1.5);   semilogy(gdb, teb_z, 'gs', 'MarkerFaceColor', 'g');
semilogy(gdb, teb_d, 'b^', 'MarkerFaceColor', 'b'); grid on; ylim([1e-5 1]);
xlabel('E_b/N_0 (dB)'); ylabel('TEB'); title(sprintf('Canal a echo (\\beta = %.2f, \\tau = %dT) : sans egaliseur, ZF, DFE', beta, tau));
legend('Sans echo (theorie)', 'Echo sans egaliseur (theorie)', 'Echo sans egaliseur (sim)', 'ZF (theorie)', 'ZF (sim)', 'DFE (sim)', 'Location', 'southwest');

% Q2 : egaliseur
fprintf('\nQ2 : il faut connaitre (ou estimer par sequence d''apprentissage) beta et tau.\n');
fprintf('  ZF : filtre 1/(1+beta z^-tau), perte de %.2f dB (bruit amplifie de 1/(1-beta^2))\n', -10*log10(1 - beta^2));
fprintf('  DFE : on retranche beta*a_(k-tau) decide, sans amplifier le bruit (propagation d''erreurs possible)\n');

% Q3 : transmission d'un texte (caracteres -> octets -> bits -> chaine -> bits -> texte)
msg = ['Theorie de l''information et codage : la capacite d''un canal est la limite superieure du debit ' ...
       'que l''on peut transmettre avec une probabilite d''erreur aussi faible que l''on veut. DIOUF Adja, ENSIM 5A ASTRE.'];
bits_msg = reshape(dec2bin(double(msg), 8).' - '0', 1, []);
bits_msg = [bits_msg zeros(1, 4*ceil(numel(bits_msg)/4) - numel(bits_msg))];       % multiple de 4 pour Hamming
bin2txt = @(bv) char(bin2dec(char(reshape(bv(1:8*floor(numel(bv)/8)), 8, []).' + '0')).');
nfaux = @(bv) sum(bin2txt(bv) ~= msg(1:numel(bin2txt(bv))));                       % caracteres faux
fprintf('\nQ3 : message de %d caracteres = %d bits\nEmis : %s\n', numel(msg), numel(bits_msg), msg);
for gd = [3 6]
    bv = transmet_bits(bits_msg, h, L, gd);                                        % sans codage
    fprintf('\n--- Eb/N0 = %d dB, SANS Hamming : %d erreurs binaires (TEB %.3f), %d caracteres faux\n', ...
            gd, sum(bv ~= bits_msg), mean(bv ~= bits_msg), nfaux(bv));
    fprintf('Recu : %s\n', bin2txt(bv));
    cb = reshape(hamming_encode(reshape(bits_msg, 4, []).').', 1, []);             % avec Hamming : Ec = 4/7 Eb
    ch = transmet_bits(cb, h, L, gd + 10*log10(4/7));
    bv = reshape(hamming_decode(reshape(ch, 7, []).').', 1, []);
    fprintf('--- Eb/N0 = %d dB, AVEC Hamming : %d erreurs binaires (TEB %.3f), %d caracteres faux\n', ...
            gd, sum(bv ~= bits_msg), mean(bv ~= bits_msg), nfaux(bv));
    fprintf('Recu : %s\n', bin2txt(bv));
end


%% ========================================================================
%  PARTIE 8 : CONCLUSION - SYNTHESE DE L'APPORT DE CHAQUE BLOC
%% ========================================================================

%% 8. Recapitulatif chiffre (valeurs calculees dans les sections precedentes)
fprintf('\n================ SYNTHESE ================\n');
fprintf('Codage de source : Huffman %.3f bit/car pour H = %.3f (compression %.2f vs 8 bits) ;\n', Lmoy, H0, compression_huffman);
fprintf('                   extension k = 10 : %.4f bit/bit pour H = %.4f.\n', Lth(end), Hext);
fprintf('Detecteur optimal : TEB 1e-3 a %.2f dB (integration) contre %.2f dB (1 echantillon), gain %.2f dB.\n', ...
        EbN0_1e3_dB, EbN0_1e3_dB + 10*log10(L), 10*log10(L));
fprintf('Codage de canal  : Hamming (7,4) avantageux a partir de %.2f dB, gain %.2f dB a 1e-4, debit x 4/7.\n', x_croise, gain_codage);
fprintf('QPSK (Gray)      : meme TEB que la BPSK, debit x2 ou bande /2 ; mapping naturel : TEB x ~1,5.\n');
fprintf('Filtrage RRC     : B99 = %.2f/T contre %.2f/T pour le filtre porte, sans perte de TEB.\n', B99_rrc, B99_porte);
fprintf('Efficacite spectrale QPSK + RRC (alpha = %.2f) : %.2f bit/s/Hz ; Shannon (canal gaussien complexe) :\n', alpha, 2/(1+alpha));
fprintf('  Eb/N0 minimal = %.2f dB, contre %.2f dB necessaires a 1e-3 sans codage.\n', ...
        10*log10((2^(2/(1+alpha)) - 1) / (2/(1+alpha))), EbN0_1e3_dB);
