function [G, H] = hamming_GH()
%HAMMING_GH  Matrices génératrice et de contrôle du code de Hamming (7,4).
%   [G, H] = hamming_GH()
%   G = [I4 | P] (4x7) : génératrice systématique, c = m*G (modulo 2)
%   H = [P' | I3] (3x7) : contrôle, H*c' = 0 pour tout mot-code c
%
%   Les lignes de P sont les restes x^3 m(x) mod g(x) des messages de poids 1
%   (voir reste_g.m), pour g(x) = 1 + x + x^3.

P = [1 1 0;
     0 1 1;
     1 1 1;
     1 0 1];
G = [eye(4), P];
H = [P.', eye(3)];
end