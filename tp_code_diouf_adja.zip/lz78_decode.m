function seq = lz78_decode(idx, sym)
%LZ78_DECODE  Décodeur de Lempel-Ziv 78.
%   seq = lz78_decode(idx, sym)
%   idx, sym : couples (indice, symbole) produits par lz78_encode
%   seq      : séquence de symboles reconstruite
%
%   Principe : le décodeur reconstruit le MEME dictionnaire que le codeur,
%   au fur et à mesure. La phrase du i-ème couple est la phrase d'indice
%   idx(i) (déjà reconstruite) suivie du symbole sym(i). Aucune table n'est
%   transmise : c'est ce qui rend le code universel.

n = numel(idx);
phrases = cell(1, n);

for i = 1:n
    if idx(i) == 0
        debut = [];                       % phrase vide
    else
        debut = phrases{idx(i)};
    end
    if sym(i) == 0                        % dernier couple : pas de symbole ajouté
        phrases{i} = debut;
    else
        phrases{i} = [debut sym(i)];
    end
end

seq = [phrases{:}];
end