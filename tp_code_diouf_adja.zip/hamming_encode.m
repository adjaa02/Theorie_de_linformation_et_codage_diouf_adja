function c = hamming_encode(m)
%HAMMING_ENCODE  Codeur de Hamming (7,4) par produit matriciel modulo 2.
%   c = hamming_encode(m)
%   m : matrice N x 4 de bits (un mot-message par ligne)
%   c : matrice N x 7 (un mot-code par ligne) : [m0 m1 m2 m3 | r0 r1 r2]
[G, ~] = hamming_GH();
c = mod(m * G, 2);
end