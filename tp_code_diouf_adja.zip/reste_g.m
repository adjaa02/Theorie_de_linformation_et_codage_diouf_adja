function r = reste_g(m)
%RESTE_G  Reste de la division de x^3 m(x) par g(x) = 1 + x + x^3 (arithmétique modulo 2).
%   r = reste_g(m)
%   m : mot-message [m0 m1 m2 m3] (coefficients en puissances croissantes)
%   r : reste [r0 r1 r2], c'est-à-dire la redondance du code systématique
%
%   Principe : c'est la division polynomiale "à la main". On part de x^3 m(x)
%   et, du degré 6 au degré 3, chaque fois que le coefficient de plus haut
%   degré vaut 1, on retranche (xor) le polynôme g(x) décalé au bon degré.

g    = [1 1 0 1];                    % 1 + x + x^3, puissances croissantes 0..3
poly = [0 0 0, m(:).'];              % x^3 m(x), puissances 0..6

for deg = 6:-1:3
    if poly(deg+1) == 1
        poly(deg-2:deg+1) = xor(poly(deg-2:deg+1), g);   % retrancher x^(deg-3) g(x)
    end
end

r = double(poly(1:3));
end