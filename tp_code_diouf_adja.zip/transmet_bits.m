function bh = transmet_bits(b, h, L, gdb)
%TRANSMET_BITS  Fait passer un vecteur de bits dans la chaîne filtrée (une voie, h et h(-t)) et rend les bits décidés.
%   gdb : rapport Eb/N0 en dB, Eb étant l'énergie par bit TRANSMIS dans la chaîne
%         (pour un message codé, passer Ec/N0 = Eb/N0 + 10 log10(4/7)).
N  = numel(h);
M  = numel(b);
g  = 10^(gdb / 10);
a0 = 1 / sqrt(2);
a  = a0 * (1 - 2*b(:).');
x  = zeros(1, M*L);  x(1:L:end) = a;
s  = filter(h, 1, [x zeros(1, N-1)]);
r  = s + sqrt(0.25 / g) * randn(size(s));
z  = filter(fliplr(h), 1, r);
bh = double(z((0:M-1) * L + N) < 0);
end