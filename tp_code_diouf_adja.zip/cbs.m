function r = cbs(b, pe)
%CBS  Canal binaire symétrique de probabilité d'erreur pe.
%   r = cbs(b, pe)
%   b  : bits émis (0 ou 1)
%   pe : probabilité qu'un bit soit inversé (même probabilité pour 0 et 1)
%   r  : bits reçus
%
%   Principe : pour chaque bit, on tire u uniforme sur [0,1]. Si u < pe,
%   le bit est inversé (ou exclusif avec 1), sinon il passe sans erreur.
%   Les erreurs sont indépendantes d'un bit à l'autre.
erreur = rand(size(b)) < pe;      % 1 là où le canal se trompe
r = double(xor(b, erreur));
end