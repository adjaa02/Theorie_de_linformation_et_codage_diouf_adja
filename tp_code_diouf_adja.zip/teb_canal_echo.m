function [teb, nerr, nb] = teb_canal_echo(h, L, gdb, beta, tau, mode, ncible, nmax)
%TEB_CANAL_ECHO  TEB d'une voie de la chaîne filtrée (h, h(-t)) avec canal à écho hc = delta(t) + beta delta(t - tau T).
%   mode : 'brut' (aucun égaliseur), 'zf' (zero-forcing = filtre inverse), 'dfe' (égaliseur à retour de décisions)
%   tau  : retard de l'écho en durées symbole (entier)
%
%   Le bruit est ajouté après le canal. Le filtre adapté étant d'énergie unité, après échantillonnage :
%       y_k = a_k + beta a_{k-tau} + n_k     (h*h vérifie Nyquist, le canal ajoute l'écho)
%   Eb est l'énergie par bit à l'émission : amplitude 1/sqrt(2) par voie, bruit de variance 0.25/g.

N  = numel(h);
g  = 10^(gdb / 10);
sg = sqrt(0.25 / g);
a0 = 1 / sqrt(2);
M  = 1e5;
nerr = 0;  nb = 0;
d  = tau * L;                               % retard de l'écho en échantillons
while nerr < ncible && nb < nmax
    b = rand(1, M) < 0.5;
    a = a0 * (1 - 2*b);
    x = zeros(1, M*L);  x(1:L:end) = a;
    s = filter(h, 1, [x zeros(1, N-1)]);
    s = s + beta * [zeros(1, d) s(1:end-d)];            % canal à écho
    r = s + sg * randn(size(s));
    z = filter(fliplr(h), 1, r);
    y = z((0:M-1) * L + N);                              % un échantillon par symbole
    switch mode
        case 'brut'
            bh = y < 0;
        case 'zf'                                        % filtre inverse 1/(1 + beta z^-tau)
            yz = filter(1, [1 zeros(1, tau-1) beta], y);
            bh = yz < 0;
        case 'dfe'                                       % on retranche l'écho des symboles déjà décidés
            ah = zeros(1, M);  bh = false(1, M);
            for k = 1:M
                if k > tau, yk = y(k) - beta * ah(k - tau); else, yk = y(k); end
                bh(k) = yk < 0;
                ah(k) = a0 * (1 - 2*bh(k));
            end
        otherwise
            error('mode inconnu');
    end
    nerr = nerr + sum(bh ~= b);
    nb = nb + M;
end
teb = nerr / nb;
end