function bits = huffman_code(idx, codes)
%HUFFMAN_CODE  Code une suite de symboles avec un code de Huffman.
%   bits  = huffman_code(idx, codes)
%   idx   : vecteur des indices des symboles à coder (1..numel(codes))
%   codes : cellule des mots de code (sortie de huffman)
%   bits  : chaîne de caractères '0' et '1' (le flux binaire codé)
%
%   Principe : on remplace chaque symbole par son mot de code, puis on
%   concatène tous les mots. [codes{idx}] fait cela en une seule opération.
bits = [codes{idx}];
end