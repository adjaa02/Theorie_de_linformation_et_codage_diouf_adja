function b = source(N, p1)
%SOURCE  Source binaire sans mémoire : N bits indépendants avec P(bit = 1) = p1.
%   b = source(N, p1)   (vecteur ligne de 0 et 1)
b = double(rand(1, N) < p1);
end
