function [idx, sym] = lz78_encode(seq, M)
%LZ78_ENCODE  Codeur de Lempel-Ziv 78.
%   [idx, sym] = lz78_encode(seq, M)
%   seq : vecteur de symboles entiers dans 1..M
%   M   : taille de l'alphabet
%   idx : indice de la phrase connue (0 = phrase vide) pour chaque couple
%   sym : symbole ajouté pour chaque couple
%
%   Principe : on lit la séquence symbole par symbole en suivant la plus
%   longue phrase déjà connue. Dès que la phrase prolongée du symbole lu
%   n'est PAS dans le dictionnaire, on émet le couple (indice, symbole) et on
%   ajoute cette nouvelle phrase au dictionnaire.
%   Si la séquence se termine au milieu d'une phrase déjà connue, on émet un
%   dernier couple (indice, 0) : le symbole 0 signifie "fin, rien à ajouter".

dico = containers.Map('KeyType', 'double', 'ValueType', 'double');
N   = numel(seq);
idx = zeros(1, N);
sym = zeros(1, N);
n   = 0;            % nombre de phrases (= de couples) émises
cur = 0;            % indice de la phrase courante (0 = phrase vide)

for t = 1:N
    s   = seq(t);
    key = cur * (M + 1) + s;       % clé unique pour la phrase "cur suivie de s"
    if isKey(dico, key)            % phrase prolongée déjà connue : on continue
        cur = dico(key);
    else                           % nouvelle phrase : on émet et on mémorise
        n = n + 1;
        dico(key) = n;
        idx(n) = cur;
        sym(n) = s;
        cur = 0;
    end
end

if cur ~= 0                        % séquence terminée au milieu d'une phrase
    n = n + 1;
    idx(n) = cur;
    sym(n) = 0;
end

idx = idx(1:n);
sym = sym(1:n);
end