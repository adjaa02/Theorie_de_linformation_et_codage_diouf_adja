function build_chaine_hamming
%BUILD_CHAINE_HAMMING  Construit le modele Simulink 'chaine_hamming' (chaine avec codage de canal).
%   Utilisation :   Parametres_hamming;  build_chaine_hamming
%   Meme structure que chaine_base : Rate Transition -> + bruit -> Buffer -> somme -> /N -> comparateur.
%   Chaine : source -> Buffer(4) -> codeur matriciel -> Unbuffer -> mapping +-A -> repetition (Rate Transition)
%            -> + bruit -> integrateur sur Lc=4L/7 echantillons -> decision -> Buffer(7)
%            -> decodeur (syndrome, correction, 4 premiers bits) -> Unbuffer -> b_rx_c.
%   Sorties To Workspace : b_tx (bits emis) et b_rx_c (bits decodes), format Array.
mdl = 'chaine_hamming';
if bdIsLoaded(mdl), close_system(mdl, 0); end
new_system(mdl);  open_system(mdl);

set_param(mdl, 'SolverType', 'Fixed-step', 'Solver', 'FixedStepDiscrete', 'FixedStep', 'Te', ...
               'StopTime', '1000', 'AutoInsertRateTranBlk', 'off');
try, set_param(mdl, 'EnableMultiTasking', 'off'); catch, end   % evite les erreurs de rate transition

S = 'simulink/';  D = 'dspbuff3/';
% ---------------- emetteur ----------------
add(mdl,'src',   [S 'Sources/Uniform Random Number'], 1,1, 'Minimum','0','Maximum','1','Seed','graine','SampleTime','Tb');
add(mdl,'p1',    [S 'Sources/Constant'],              1,2, 'Value','p1_chaine','SampleTime','Tb');
add(mdl,'cmp',   [S 'Logic and Bit Operations/Relational Operator'], 2,1, 'Operator','<');
add(mdl,'dtc',   [S 'Signal Attributes/Data Type Conversion'], 3,1, 'OutDataTypeStr','double');
add(mdl,'tx_ws', [S 'Sinks/To Workspace'],            4,2, 'VariableName','b_tx','SaveFormat','Array','MaxDataPoints','inf','SampleTime','-1');
add(mdl,'buf4',  [D 'Buffer'],                        4,1, 'N','4');
add(mdl,'enc',   [S 'Math Operations/Gain'],          5,1, 'Gain','Gt','Multiplication','Matrix(K*u)');
add(mdl,'two1',  [S 'Sources/Constant'],              5,2, 'Value','2');
add(mdl,'mod1',  [S 'Math Operations/Math Function'], 6,1, 'Operator','mod');
add(mdl,'unb7',  [D 'Unbuffer'],                      7,1);
add(mdl,'gA',    [S 'Math Operations/Gain'],          8,1, 'Gain','2*A');
add(mdl,'bA',    [S 'Math Operations/Bias'],          9,1, 'Bias','-A');
add(mdl,'rt',    [S 'Signal Attributes/Rate Transition'], 10,1, 'OutPortSampleTime','Te','Integrity','off');
% ---------------- canal ----------------
add(mdl,'noise', [S 'Sources/Random Number'],         10,2, 'Mean','0','Variance','sigma2','Seed','graine+1','SampleTime','Te');
add(mdl,'sumCh', [S 'Math Operations/Sum'],           11,1, 'Inputs','++');
% ---------------- detecteur optimal (integrateur sur Lc echantillons) ----------------
add(mdl,'bufL',  [D 'Buffer'],                        11,3, 'N','Lc');
add(mdl,'sumEl', [S 'Math Operations/Sum of Elements'], 10,3);
add(mdl,'gm',    [S 'Math Operations/Gain'],          9,3, 'Gain','1/Lc');
add(mdl,'thr',   [S 'Sources/Constant'],              8,4, 'Value','seuil','SampleTime','Tc');
add(mdl,'dec1',  [S 'Logic and Bit Operations/Relational Operator'], 8,3, 'Operator','>');
add(mdl,'dtc2',  [S 'Signal Attributes/Data Type Conversion'], 7,3, 'OutDataTypeStr','double');
% ---------------- decodeur de Hamming ----------------
add(mdl,'buf7',  [D 'Buffer'],                        6,3, 'N','7');
add(mdl,'gH',    [S 'Math Operations/Gain'],          5,3, 'Gain','Hmat','Multiplication','Matrix(K*u)');
add(mdl,'two2',  [S 'Sources/Constant'],              5,4, 'Value','2');
add(mdl,'mod2',  [S 'Math Operations/Math Function'], 4,3, 'Operator','mod');
add(mdl,'gK',    [S 'Math Operations/Gain'],          3,3, 'Gain','[4 2 1]','Multiplication','Matrix(K*u)');
add(mdl,'cHdec', [S 'Sources/Constant'],              3,4, 'Value','Hdec');
add(mdl,'eq',    [S 'Logic and Bit Operations/Relational Operator'], 2,3, 'Operator','==');
add(mdl,'xr',    [S 'Logic and Bit Operations/Logical Operator'], 2,4, 'Operator','XOR','Inputs','2');
add(mdl,'sel',   [S 'Signal Routing/Selector'],       1,4, 'InputPortWidth','7','IndexOptions','Index vector (dialog)','Indices','[1 2 3 4]');
add(mdl,'dtc3',  [S 'Signal Attributes/Data Type Conversion'], 1,5, 'OutDataTypeStr','double');
add(mdl,'unb4',  [D 'Unbuffer'],                      2,5);
add(mdl,'rx_ws', [S 'Sinks/To Workspace'],            3,5, 'VariableName','b_rx_c','SaveFormat','Array','MaxDataPoints','inf','SampleTime','-1');
% valeur de Buffer : sortie vecteur (comme dans chaine_base)
for b = {'buf4','bufL','buf7'}
    try, set_param([mdl '/' b{1}], 'OutputFrames', 'off'); catch, end
end

% ---------------- liaisons ----------------
L2 = { 'src','cmp',1; 'p1','cmp',2; 'dtc','tx_ws',1; 'dtc','buf4',1; 'buf4','enc',1; 'enc','mod1',1; ...
       'unb7','gA',1; 'gA','bA',1; 'bA','rt',1; 'rt','sumCh',1; 'noise','sumCh',2; 'sumCh','bufL',1; ...
       'bufL','sumEl',1; 'sumEl','gm',1; 'gm','dec1',1; 'dec1','dtc2',1; 'dtc2','buf7',1; 'buf7','gH',1; ...
       'gH','mod2',1; 'mod2','gK',1; 'gK','eq',1; 'buf7','xr',1; 'eq','xr',2; 'xr','sel',1; ...
       'sel','dtc3',1; 'dtc3','unb4',1; 'unb4','rx_ws',1 };
for i = 1:size(L2,1)
    link(mdl, L2{i,1}, 1, L2{i,2}, L2{i,3});
end
link(mdl,'cmp',1,'dtc',1);  link(mdl,'two1',1,'mod1',2);  link(mdl,'mod1',1,'unb7',1);
link(mdl,'thr',1,'dec1',2); link(mdl,'two2',1,'mod2',2);  link(mdl,'cHdec',1,'eq',2);

save_system(mdl);
fprintf('Modele %s.slx cree. Lance Parametres_hamming puis pilotage_simulink_hamming.\n', mdl);
end

% ---------- fonctions locales ----------
function add(mdl, name, lib, col, row, varargin)
% place le bloc sur une grille (colonne, ligne) et fixe ses parametres
    x = 30 + 140*col;  y = 30 + 90*row;
    add_block(lib, [mdl '/' name], 'Position', [x y x+60 y+40], varargin{:});
end
function link(mdl, a, pa, b, pb)
    add_line(mdl, sprintf('%s/%d', a, pa), sprintf('%s/%d', b, pb), 'autorouting', 'smart');
end