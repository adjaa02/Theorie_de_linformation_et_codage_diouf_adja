%% pilotage_simple.m  --  TEB sans / avec codage de Hamming (7,4) avec le modele simplifie chaine_simple
%  Etapes : (1) ce script definit les parametres, (2) construit le modele s'il n'existe pas,
%           (3) simule pour Eb/N0 = 0..9 dB, (4) trace TEB simule, TEB theorique et limites de Shannon.
clear; clc; close all;

%% Parametres
p1_chaine = 0.5;                 % bits equiprobables
graine    = 1;
a         = sqrt(4/7);           % amplitude d'un bit code (Ec = 4/7 Eb, avec A = 1, Tb = 1)
[G, H] = hamming_GH();
Gt = G.';  Hmat = H;  Hdec = ([4 2 1]*H).';
EbN0dB   = 0:9;
NbMots   = 2e6;                  % mots de 4 bits par point (= 8e6 bits d'information)
Q = @(x) 0.5*erfc(x/sqrt(2));

modele = 'chaine_simple';
if ~exist([modele '.slx'], 'file'), build_chaine_simple; end
load_system(modele);
set_param(modele, 'StopTime', num2str(NbMots-1));      % 1 mot par pas de temps
% set_param(modele, 'SimulationMode', 'accelerator');  % (optionnel) plus rapide

%% Simulation
TEB_nc = zeros(size(EbN0dB));  TEB_c = TEB_nc;  Nb = TEB_nc;  e_nc = TEB_nc;  e_c = TEB_nc;
for k = 1:numel(EbN0dB)
    EbN0 = 10^(EbN0dB(k)/10);
    sigma2_b = 1/(2*EbN0);                  % = N0/(2 Tb) avec Eb = 1 : bruit apres integration
    assignin('base', 'sigma2_b', sigma2_b);
    out = sim(modele);
    m_tx = double(out.m_tx);  m_nc = double(out.m_rx_nc);  m_c = double(out.m_rx_c);
    e_nc(k) = sum(m_tx(:) ~= m_nc(:));      e_c(k) = sum(m_tx(:) ~= m_c(:));
    Nb(k)   = numel(m_tx);
    TEB_nc(k) = e_nc(k)/Nb(k);  TEB_c(k) = e_c(k)/Nb(k);
    fprintf('Eb/N0 = %d dB : sans codage %.3e (%d err) | avec codage %.3e (%d err)\n', ...
            EbN0dB(k), TEB_nc(k), e_nc(k), TEB_c(k), e_c(k));
end
if any([e_nc e_c] < 100), warning('Certains points ont moins de 100 erreurs : TEB peu fiable.'); end
IC_nc = 1.96*sqrt(TEB_nc.*(1-TEB_nc)./Nb);  IC_c = 1.96*sqrt(TEB_c.*(1-TEB_c)./Nb);

%% Figure
x_th = -2:0.1:9;  EbN0_th = 10.^(x_th/10);
Pb_nc = Q(sqrt(2*EbN0_th));
Pb_c  = arrayfun(@Pb_exact, Q(sqrt(2*(4/7)*EbN0_th)));
figure;
semilogy(x_th, Pb_nc, 'b-', x_th, Pb_c, 'r-'); hold on;
errorbar(EbN0dB, TEB_nc, IC_nc, 'bo');  errorbar(EbN0dB, TEB_c, IC_c, 'rs');
yl = [1e-6 1];  plot([0.24 0.24], yl, 'k--');  plot([-1.59 -1.59], yl, 'k:');
grid on; xlim([-2 9]); ylim(yl);
xlabel('E_b/N_0 (dB)'); ylabel('TEB');
legend('sans codage (theorie)', 'Hamming (theorie)', 'sans codage (Simulink)', 'Hamming (Simulink)', ...
       'Shannon R = 4/7 : 0,24 dB', 'limite absolue : -1,59 dB', 'Location', 'southwest');
title('TEB avec et sans codage de Hamming (7,4), canal gaussien');

function Pb = Pb_exact(p)
% probabilite exacte d'erreur sur un bit d'information apres decodage (128 motifs d'erreur)
    E = dec2bin(0:127) - '0';
    mh = hamming_decode(E);
    w = sum(E, 2);
    Pb = sum(p.^w .* (1-p).^(7-w) .* sum(mh, 2)) / 4;
end