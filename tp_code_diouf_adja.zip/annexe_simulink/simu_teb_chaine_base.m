%% Pilotage du modèle Simulink chaine_base : TEB en fonction de Eb/N0 (question 12)
clear; clc; close all;

parametres;                             % définit A, L, Tb, Te, graine, p1_chaine, seuil, sigma2...
modele = 'chaine_base';
load_system(modele);
Q = @(x) 0.5 * erfc(x / sqrt(2));

%% 1) Mesure du retard de la chaîne : simulation SANS bruit
%    Sans bruit, la décision doit redonner exactement les bits émis, mais décalés
%    d'un certain nombre de bits (retards des blocs Rate Transition et Buffer).
sigma2 = 0;
set_param(modele, 'StopTime', '1000');
out = sim(modele);
btx = out.b_tx(:);  brx = out.b_rx(:);
n = min(numel(btx), numel(brx));  btx = btx(1:n);  brx = brx(1:n);

nerr_d = zeros(1, 4);
for d = 0:3
    nerr_d(d+1) = sum(brx(d+1:end) ~= btx(1:end-d));    % brx(k+d) doit valoir btx(k)
end
[~, id] = min(nerr_d);
retard = id - 1;
fprintf('Erreurs sans bruit pour un retard de 0 a 3 bits : %s\n', mat2str(nerr_d));
fprintf('Retard de la chaine : %d bit(s)\n', retard);

%% 2) TEB pour Eb/N0 de 0 a 9 dB
EbN0_dB = 0:1:9;
EbN0    = 10.^(EbN0_dB / 10);
th      = Q(sqrt(2 * EbN0));            % TEB théorique avec intégration
th_sans = Q(sqrt(2 * EbN0 / L));        % TEB théorique sans intégration
Nmax    = 2e6;                          % limite de bits par point (augmenter si le temps le permet)

teb = zeros(size(EbN0_dB));  teb_sans = zeros(size(EbN0_dB));
nerr = zeros(size(EbN0_dB)); nb = zeros(size(EbN0_dB));
for i = 1:numel(EbN0_dB)
    sigma2 = (A^2 * Tb / EbN0(i)) * L / (2*Tb);         % variance du bruit par échantillon
    Nb = min(max(2e4, ceil(200 / th(i))), Nmax);        % assez de bits pour ~200 erreurs
    set_param(modele, 'StopTime', num2str(Nb * Tb));
    out = sim(modele);
    btx = out.b_tx(:);  brx = out.b_rx(:);  brs = out.b_rx_sans(:);
    n = min([numel(btx), numel(brx), numel(brs)]);
    btx = btx(1:n);  brx = brx(1:n);  brs = brs(1:n);
    e  = brx(retard+1:end) ~= btx(1:end-retard);
    es = brs(retard+1:end) ~= btx(1:end-retard);
    teb(i) = mean(e);  teb_sans(i) = mean(es);
    nerr(i) = sum(e);  nb(i) = numel(e);
    fprintf('Eb/N0 = %d dB : %d bits, %d erreurs, TEB = %.2e (theorie %.2e)\n', ...
            EbN0_dB(i), nb(i), nerr(i), teb(i), th(i));
end

figure;
semilogy(EbN0_dB, th, 'b-', 'LineWidth', 1.5); hold on;
semilogy(EbN0_dB, max(teb, 1e-7), 'bo', 'MarkerFaceColor', 'b');
semilogy(EbN0_dB, th_sans, 'r-', 'LineWidth', 1.5);
semilogy(EbN0_dB, teb_sans, 'rs', 'MarkerFaceColor', 'r');
grid on; xlabel('E_b/N_0 (dB)'); ylabel('TEB');
title(sprintf('Simulink : TEB de la chaine de base (L = %d)', L));
legend('Theorie avec integration', 'Simulink avec integration', ...
       'Theorie sans integration', 'Simulink sans integration', 'Location', 'southwest');
ylim([1e-6 1]);