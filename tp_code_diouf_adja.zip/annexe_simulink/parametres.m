%% Paramètres de la chaîne de base (à exécuter AVANT chaque simulation Simulink)
%  Ce script définit dans l'espace de travail toutes les variables lues par
%  le modèle chaine_base.slx.

P = parametres_perso('DIOUF Adja');     % paramètres personnels

A      = P.A;                           % amplitude : bit 0 -> -A, bit 1 -> +A
L      = P.L;                           % échantillons par bit
Tb     = 1;                             % durée d'un bit (unité de référence)
Te     = Tb / L;                        % période d'échantillonnage du modèle
graine = P.graine;                      % graine des blocs aléatoires (résultats reproductibles)

p1_chaine = 0.5;                        % bits équiprobables (parties 3 à 7)
seuil     = 0;                          % seuil de décision nul

% --- bruit : variance par échantillon pour un Eb/N0 donné (question 10) ---
EbN0_dB = 6;                            % valeur pour un essai ponctuel
EbN0    = 10^(EbN0_dB / 10);            % rapport linéaire
Eb      = A^2 * Tb;                     % énergie par bit
N0      = Eb / EbN0;                    % densité spectrale de bruit
sigma2  = N0 * L / (2*Tb);              % variance du bruit par échantillon

Nbits = 1000;                           % nombre de bits simulés (durée = Nbits*Tb)