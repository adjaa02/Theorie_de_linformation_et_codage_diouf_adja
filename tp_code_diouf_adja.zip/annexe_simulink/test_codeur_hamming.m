%% Questions 4 et 5 : validation du codeur de Hamming à registre à décalage (Simulink)
%  Modèle à construire : codeur_hamming.slx (voir les explications)
%    - From Workspace  : variable 'entree' (format [temps, valeur]), sample time Tc
%    - To Workspace    : 'sortie' (bit de sortie y) et 'etat' (Mux de s0, s1, s2)
clear; clc;

Tc = 1;                                   % période d'horloge du registre (1 pour ce test)
modele = 'codeur_hamming';
load_system(modele);

M = dec2bin(0:15) - '0';                  % les 16 messages [m0 m1 m2 m3], un par ligne

% Flux série d'entrée : pour chaque message, m3 m2 m1 m0 (poids fort d'abord),
% puis 3 zéros pendant la phase de sortie de la redondance.
flux        = [fliplr(M), zeros(16, 3)];  % 16 x 7
entree_data = reshape(flux.', [], 1);     % mot après mot
entree      = [(0:numel(entree_data)-1).' * Tc, entree_data];   % [t, u] pour From Workspace

set_param(modele, 'StopTime', num2str((numel(entree_data) - 1) * Tc));
out = sim(modele);
y = double(out.sortie(:));

% Le circuit sort, pour chaque mot : m3 m2 m1 m0 r2 r1 r0 (poids fort d'abord).
% On remet chaque partie dans l'ordre du codeur matriciel : [m0 m1 m2 m3 | r0 r1 r2].
Y = reshape(y, 7, 16).';
C_sim = [fliplr(Y(:, 1:4)), fliplr(Y(:, 5:7))];
C_ref = hamming_encode(M);

fprintf('Mots-codes identiques au codeur matriciel : %d sur 16\n', sum(all(C_sim == C_ref, 2)));

% --- table des états du registre pour le message m = [1 0 1 1] ---
k = find(all(M == [1 0 1 1], 2));         % numéro du message dans la liste
lignes = (k - 1) * 7 + (1:8);             % états avant chaque coup d'horloge, puis état final
etat = double(out.etat);
disp('Table des etats pour m = [1 0 1 1]   (colonnes : coup d''horloge | s0 s1 s2 | entree | sortie)');
disp([(0:7).', etat(lignes, :), [entree_data((k-1)*7 + (1:7)); NaN], [y((k-1)*7 + (1:7)); NaN]]);
fprintf('Mot-code obtenu pour m = [1 0 1 1] : %s (attendu %s)\n', ...
        mat2str(C_sim(k, :)), mat2str(C_ref(k, :)));