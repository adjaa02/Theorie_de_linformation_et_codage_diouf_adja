function build_chaine_simple
%BUILD_CHAINE_SIMPLE  Modele Simulink simplifie 'chaine_simple' : un seul pas de temps (1 mot = 1 pas).
%   Utilisation :  build_chaine_simple
%   Principe : apres l'integrateur, le canal gaussien equivaut a UN echantillon par bit :
%   r = x + n, avec n de variance sigma2_b = N0/(2Tb) (cf. partie 3, question 11).
%   On travaille donc directement avec des VECTEURS (4 bits / 7 bits), sans Buffer, Unbuffer,
%   Rate Transition ni integrateur. Les deux chaines (sans / avec codage) partagent la meme source.
mdl = 'chaine_simple';
if bdIsLoaded(mdl), close_system(mdl, 0); end
new_system(mdl);  open_system(mdl);
set_param(mdl, 'SolverType','Fixed-step', 'Solver','FixedStepDiscrete', 'FixedStep','1', 'StopTime','1000');

S = 'simulink/';
% --- source : 4 bits par pas de temps ---
add(mdl,'src',  [S 'Sources/Uniform Random Number'], 1,1, 'Minimum','[0 0 0 0]','Maximum','[1 1 1 1]','Seed','graine','SampleTime','1');
add(mdl,'cmp',  [S 'Logic and Bit Operations/Compare To Constant'], 2,1, 'relop','<','const','p1_chaine');
add(mdl,'dtc',  [S 'Signal Attributes/Data Type Conversion'], 3,1, 'OutDataTypeStr','double');
add(mdl,'tx_ws',[S 'Sinks/To Workspace'], 4,0, 'VariableName','m_tx','SaveFormat','Array','MaxDataPoints','inf','SampleTime','-1');

% --- chaine SANS codage : x = +-1, bruit, decision ---
add(mdl,'gN',   [S 'Math Operations/Gain'], 4,3, 'Gain','2');
add(mdl,'bN',   [S 'Math Operations/Bias'], 5,3, 'Bias','-1');
add(mdl,'nN',   [S 'Sources/Random Number'], 6,4, 'Mean','zeros(1,4)','Variance','sigma2_b','Seed','graine+1','SampleTime','1');
add(mdl,'sN',   [S 'Math Operations/Sum'], 7,3, 'Inputs','++');
add(mdl,'dN',   [S 'Logic and Bit Operations/Compare To Constant'], 8,3, 'relop','>','const','0');
add(mdl,'cN',   [S 'Signal Attributes/Data Type Conversion'], 9,3, 'OutDataTypeStr','double');
add(mdl,'wN',   [S 'Sinks/To Workspace'], 10,3, 'VariableName','m_rx_nc','SaveFormat','Array','MaxDataPoints','inf','SampleTime','-1');

% --- chaine AVEC codage : codeur, mapping +-a (a = sqrt(4/7)), bruit, decision, decodeur ---
add(mdl,'enc',  [S 'Math Operations/Gain'], 4,1, 'Gain','Gt','Multiplication','Matrix(K*u)');
add(mdl,'two1', [S 'Sources/Constant'], 4,2, 'Value','2');
add(mdl,'mod1', [S 'Math Operations/Math Function'], 5,1, 'Operator','mod');
add(mdl,'gA',   [S 'Math Operations/Gain'], 6,1, 'Gain','2*a');
add(mdl,'bA',   [S 'Math Operations/Bias'], 7,1, 'Bias','-a');
add(mdl,'nC',   [S 'Sources/Random Number'], 8,2, 'Mean','zeros(1,7)','Variance','sigma2_b','Seed','graine+2','SampleTime','1');
add(mdl,'sC',   [S 'Math Operations/Sum'], 9,1, 'Inputs','++');
add(mdl,'dC',   [S 'Logic and Bit Operations/Compare To Constant'], 10,1, 'relop','>','const','0');
add(mdl,'cC',   [S 'Signal Attributes/Data Type Conversion'], 11,1, 'OutDataTypeStr','double');
add(mdl,'gH',   [S 'Math Operations/Gain'], 11,2, 'Gain','Hmat','Multiplication','Matrix(K*u)');
add(mdl,'two2', [S 'Sources/Constant'], 10,5, 'Value','2');
add(mdl,'mod2', [S 'Math Operations/Math Function'], 12,2, 'Operator','mod');
add(mdl,'gK',   [S 'Math Operations/Gain'], 13,2, 'Gain','[4 2 1]','Multiplication','Matrix(K*u)');
add(mdl,'cH',   [S 'Sources/Constant'], 13,3, 'Value','Hdec');
add(mdl,'eq',   [S 'Logic and Bit Operations/Relational Operator'], 14,2, 'Operator','==');
add(mdl,'xr',   [S 'Logic and Bit Operations/Logical Operator'], 14,1, 'Operator','XOR','Inputs','2');
add(mdl,'sel',  [S 'Signal Routing/Selector'], 15,1, 'InputPortWidth','7','IndexOptions','Index vector (dialog)','Indices','[1 2 3 4]');
add(mdl,'cD',   [S 'Signal Attributes/Data Type Conversion'], 16,1, 'OutDataTypeStr','double');
add(mdl,'wC',   [S 'Sinks/To Workspace'], 17,1, 'VariableName','m_rx_c','SaveFormat','Array','MaxDataPoints','inf','SampleTime','-1');

% --- liaisons ---
P = { 'src','cmp'; 'cmp','dtc'; 'dtc','tx_ws'; 'dtc','gN'; 'gN','bN'; 'bN','sN'; 'sN','dN'; 'dN','cN'; 'cN','wN'; ...
      'dtc','enc'; 'enc','mod1'; 'mod1','gA'; 'gA','bA'; 'bA','sC'; 'sC','dC'; 'dC','cC'; 'cC','gH'; 'gH','mod2'; ...
      'mod2','gK'; 'gK','eq'; 'cC','xr'; 'eq','xr'; 'xr','sel'; 'sel','cD'; 'cD','wC' };
for i = 1:size(P,1)
    pin = 1;
    if strcmp(P{i,1},'eq') && strcmp(P{i,2},'xr'), pin = 2; end
    link(mdl, P{i,1}, 1, P{i,2}, pin);
end
link(mdl,'nN',1,'sN',2);  link(mdl,'nC',1,'sC',2);
link(mdl,'two1',1,'mod1',2);  link(mdl,'two2',1,'mod2',2);  link(mdl,'cH',1,'eq',2);
save_system(mdl);
fprintf('Modele %s.slx cree.\n', mdl);
end

function add(mdl, name, lib, col, row, varargin)
    x = 30 + 110*col;  y = 30 + 80*row;
    add_block(lib, [mdl '/' name], 'Position', [x y x+60 y+40], varargin{:});
end
function link(mdl, a, pa, b, pb)
    add_line(mdl, sprintf('%s/%d', a, pa), sprintf('%s/%d', b, pb), 'autorouting', 'smart');
end