%% Parametres_hamming.m  --  parametres de la chaine avec codage de Hamming (7,4)
%  A lancer AVANT build_chaine_hamming, chaine_base, chaine_hamming ou pilotage_simulink_hamming.
%  Memes noms de variables que dans ta chaine_base (A, Tb, L, Te, sigma2, seuil, graine, p1_chaine).
A  = 1;  Tb = 1;                 % Eb = A^2*Tb = 1 (partie 4 : 1 bit d'information = Tb)
L  = 14;                         % echantillons par bit : MULTIPLE DE 7 (4L/7 echantillons par bit code)
assert(mod(L,7) == 0, 'L doit etre un multiple de 7');
Te = Tb/L;                       % pas fondamental du solveur
Tc = 4*Tb/7;                     % duree d'un bit code (debit code = 7/(4Tb))
Lc = 4*L/7;                      % echantillons par bit code

EbN0dB = 6;                      % valeur par defaut (le script de pilotage la fait varier)
EbN0   = 10^(EbN0dB/10);
N0     = A^2*Tb/EbN0;
sigma2 = N0/(2*Te);              % variance du bruit par echantillon = N0*L/(2*Tb)

seuil     = 0;                   % seuil de decision (bits equiprobables)
p1_chaine = 0.5;                 % probabilite d'emettre un 1
graine    = 1;                   % graine des generateurs aleatoires

% Code de Hamming (7,4) : matrices utilisees par les blocs Simulink
[G, H] = hamming_GH();
Gt   = G.';                      % 7x4 : c' = Gt * m'   (produit matriciel du codeur)
Hmat = H;                        % 3x7 : s' = Hmat * r' (syndrome)
Hdec = ([4 2 1] * H).';          % 7x1 : [6 3 7 5 4 2 1]