%% Question 6 : validation du décodeur de Hamming (7,4) sous Simulink
%  Modèle à construire : decodeur_hamming.slx
%    - From Workspace : variable 'mots' (format [temps, r1 ... r7]), sample time Tw
%    - To Workspace   : 'mhat_sim' (message décodé, 4 bits) et 's_sim' (syndrome, 3 bits), format Array
clear; clc;

Tw = 1;                                   % un mot reçu par pas de temps
[~, H] = hamming_GH();
Hdec = ([4 2 1] * H).';                   % numéro de syndrome de chaque colonne de H (colonne 7x1)
fprintf('Hdec = %s (syndrome lu comme un nombre, pour une erreur en position 1..7)\n', mat2str(Hdec.'));

modele = 'decodeur_hamming';
load_system(modele);

M = dec2bin(0:15) - '0';                  % 16 messages
C = hamming_encode(M);                    % 16 mots-codes

% --- cas de test : sans erreur, une erreur à chacune des 7 positions, puis toutes les paires d'erreurs ---
R = C;  Mref = M;
for j = 1:7
    Rj = C;  Rj(:, j) = 1 - Rj(:, j);
    R = [R; Rj];  Mref = [Mref; M];
end
nb_simple = size(R, 1);                   % 128 mots : 0 ou 1 erreur
paires = nchoosek(1:7, 2);
for k = 1:size(paires, 1)
    Rk = C;
    Rk(:, paires(k, :)) = 1 - Rk(:, paires(k, :));
    R = [R; Rk];  Mref = [Mref; M];
end

mots = [(0:size(R, 1) - 1).' * Tw, R];
set_param(modele, 'StopTime', num2str((size(R, 1) - 1) * Tw));
out = sim(modele);
mhat_sim = double(out.mhat_sim);
s_sim    = double(out.s_sim);

% --- comparaison avec la référence Matlab ---
[mhat_ref, ~, s_ref] = hamming_decode(R);
fprintf('\nSyndromes identiques a la reference Matlab : %d mots sur %d\n', sum(all(s_sim == s_ref, 2)), size(R, 1));
fprintf('Messages decodes identiques a la reference Matlab : %d mots sur %d\n', sum(all(mhat_sim == mhat_ref, 2)), size(R, 1));

% --- performances du décodeur ---
fprintf('\nSans erreur : %d messages corrects sur 16\n', sum(all(mhat_sim(1:16, :) == Mref(1:16, :), 2)));
for j = 1:7
    lignes = 16*j + (1:16);
    fprintf('Erreur simple en position %d : %d messages corriges sur 16\n', j, ...
            sum(all(mhat_sim(lignes, :) == Mref(lignes, :), 2)));
end
double_err = nb_simple + 1:size(R, 1);
fprintf('Deux erreurs : %d messages faux sur %d (le decodeur corrige a tort)\n', ...
        sum(any(mhat_sim(double_err, :) ~= Mref(double_err, :), 2)), numel(double_err));