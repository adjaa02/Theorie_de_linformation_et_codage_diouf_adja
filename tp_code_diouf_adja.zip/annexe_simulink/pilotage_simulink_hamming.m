%% pilotage_simulink_hamming.m  --  TEB de la chaine Simulink SANS et AVEC codage de Hamming (7,4)
%  Utilise tes modeles : chaine_base.slx (sortie b_tx / b_rx, avec integrateur)
%                        chaine_hamming.slx (cree par build_chaine_hamming.m : b_tx / b_rx_c)
%  Le TEB est calcule ICI a partir des bits emis et recus (pas de bloc Error Rate Calculation) :
%  le retard de la chaine est mesure automatiquement sur une simulation SANS bruit.
clear; clc; close all;
Parametres_hamming;                          % definit A, Tb, L, Te, Tc, Lc, sigma2, seuil, ... (L multiple de 7)

modele_nc = 'chaine_base';                   % chaine sans codage
modele_c  = 'chaine_hamming';                % chaine avec codage
EbN0dB    = 0:7;                             % au-dela de 7 dB il faut des millions de bits
NbBits    = 1e6;                             % bits d'information simules par point
nb_err_min = 100;                            % en dessous, le TEB n'est pas fiable
Q = @(x) 0.5*erfc(x/sqrt(2));

load_system(modele_nc);  load_system(modele_c);
for m = {modele_nc, modele_c}
    set_param(m{1}, 'StopTime', num2str(NbBits*Tb));
    % set_param(m{1}, 'SimulationMode', 'accelerator');   % (optionnel) pour aller plus vite
end

%% 1) mesure des retards sans bruit
sigma2 = 0;  assignin('base', 'sigma2', sigma2);
set_param(modele_nc, 'StopTime', num2str(2000*Tb));  set_param(modele_c, 'StopTime', num2str(2000*Tb));
out = sim(modele_nc);  d_nc = retard(donnees(out.b_tx), donnees(out.b_rx));
out = sim(modele_c);   d_c  = retard(donnees(out.b_tx), donnees(out.b_rx_c));
fprintf('Retard sans codage : %d bit(s) ; avec codage : %d bit(s)\n', d_nc, d_c);
set_param(modele_nc, 'StopTime', num2str(NbBits*Tb));  set_param(modele_c, 'StopTime', num2str(NbBits*Tb));

%% 2) boucle sur Eb/N0
TEB_nc = zeros(size(EbN0dB));  TEB_c = TEB_nc;  nerr_nc = TEB_nc;  nerr_c = TEB_nc;  Nb_nc = TEB_nc;  Nb_c = TEB_nc;
for k = 1:numel(EbN0dB)
    EbN0   = 10^(EbN0dB(k)/10);
    N0     = A^2*Tb/EbN0;
    sigma2 = N0/(2*Te);                      % = N0*L/(2*Tb)
    assignin('base', 'sigma2', sigma2);

    out = sim(modele_nc);
    [nerr_nc(k), Nb_nc(k)] = compter(donnees(out.b_tx), donnees(out.b_rx), d_nc);
    out = sim(modele_c);
    [nerr_c(k),  Nb_c(k)]  = compter(donnees(out.b_tx), donnees(out.b_rx_c), d_c);

    TEB_nc(k) = nerr_nc(k)/Nb_nc(k);   TEB_c(k) = nerr_c(k)/Nb_c(k);
    fprintf('Eb/N0 = %d dB : sans codage %.3e (%d err) | avec codage %.3e (%d err)\n', ...
            EbN0dB(k), TEB_nc(k), nerr_nc(k), TEB_c(k), nerr_c(k));
end
if any([nerr_nc nerr_c] < nb_err_min)
    warning('Certains points ont moins de %d erreurs : TEB peu fiable (augmenter NbBits).', nb_err_min);
end
IC_nc = 1.96*sqrt(TEB_nc.*(1-TEB_nc)./Nb_nc);        % intervalle de confiance a 95 %
IC_c  = 1.96*sqrt(TEB_c .*(1-TEB_c )./Nb_c );

%% 3) figure : simulation vs theorie vs limites de Shannon
x_th  = -2:0.1:9;  EbN0_th = 10.^(x_th/10);
Pb_nc = Q(sqrt(2*EbN0_th));
p_th  = Q(sqrt(2*(4/7)*EbN0_th));
Pb_c  = arrayfun(@Pb_exact, p_th);
figure;
semilogy(x_th, Pb_nc, 'b-', x_th, Pb_c, 'r-'); hold on;
errorbar(EbN0dB, TEB_nc, IC_nc, 'bo');  errorbar(EbN0dB, TEB_c, IC_c, 'rs');
yl = [1e-6 1];
plot([0.24 0.24], yl, 'k--');  plot([-1.59 -1.59], yl, 'k:');
grid on; xlim([-2 9]); ylim(yl);
xlabel('E_b/N_0 (dB)'); ylabel('TEB');
legend('sans codage (theorie)', 'Hamming (theorie)', 'sans codage (Simulink)', 'Hamming (Simulink)', ...
       'Shannon R = 4/7 : 0,24 dB', 'limite absolue : -1,59 dB', 'Location', 'southwest');
title('TEB de la chaine Simulink, avec et sans codage de Hamming (7,4)');

%% ---------------- fonctions locales ----------------
function x = donnees(v)
% accepte un timeseries (format par defaut de To Workspace) ou un tableau
    if isa(v, 'timeseries'), v = v.Data; end
    x = double(v(:));
end
function d = retard(btx, brx)
% retard (en bits) qui annule les erreurs sur une simulation sans bruit
    n = min(numel(btx), numel(brx)) - 60;
    e = arrayfun(@(dd) sum(btx(1:n) ~= brx(dd+1:dd+n)), 0:50);
    [~, i] = min(e);  d = i - 1;
    if e(i) > 0, warning('Aucun retard n''annule les erreurs sans bruit : verifier la chaine.'); end
end
function [nerr, nb] = compter(btx, brx, d)
    n = min(numel(btx), numel(brx)) - d;
    nerr = sum(btx(1:n) ~= brx(d+1:d+n));  nb = n;
end
function Pb = Pb_exact(p)
% probabilite d'erreur exacte sur un bit d'information apres decodage (enumeration des 128 erreurs)
    E = dec2bin(0:127) - '0';
    mh = hamming_decode(E);
    w = sum(E, 2);
    Pb = sum(p.^w .* (1-p).^(7-w) .* sum(mh, 2)) / 4;
end