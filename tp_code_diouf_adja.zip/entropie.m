function [H, symboles, p] = entropie(seq)
%ENTROPIE  Entropie empirique d'une séquence de symboles (bit/symbole).
%   [H, symboles, p] = entropie(seq)
%   seq      : séquence de symboles (chaîne de caractères ou vecteur de nombres)
%   H        : entropie d'ordre 0, H = -sum(p log2 p)
%   symboles : alphabet observé (valeurs distinctes, triées)
%   p        : fréquence de chaque symbole de l'alphabet
[symboles, ~, idx] = unique(seq);
cpt = accumarray(idx(:), 1);          % nombre d'occurrences de chaque symbole
p = cpt / sum(cpt);
H = -sum(p .* log2(p));
end
