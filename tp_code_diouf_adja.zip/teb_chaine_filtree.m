function [teb, nerr, nb] = teb_chaine_filtree(h, L, gdb, offset, ncible, nmax)
%TEB_CHAINE_FILTREE  TEB d'une voie (I ou Q) de la chaîne sur-échantillonnée avec filtres h et h(-t).
%   [teb, nerr, nb] = teb_chaine_filtree(h, L, gdb, offset, ncible, nmax)
%   h       : filtre de mise en forme, énergie unité (le filtre adapté est fliplr(h))
%   L       : échantillons par symbole
%   gdb     : Eb/N0 en dB
%   offset  : décalage de l'instant d'échantillonnage, en échantillons (T/L chacun)
%   ncible  : on s'arrête après ce nombre d'erreurs ...
%   nmax    : ... ou après ce nombre de symboles
%
%   Conventions (Es = 1 pour QPSK, donc Eb = 1/2 et amplitude 1/sqrt(2) par voie) :
%   N0 = Eb/g = 0.5/g ; le bruit blanc a la variance N0/2 = 0.25/g par échantillon et par voie.
%   Les filtres étant d'énergie unité, cette variance est aussi celle du bruit après le filtre adapté.
%   Retard de la chaîne : N-1 échantillons (somme des moitiés des deux filtres), le symbole k
%   est donc échantillonné à l'indice (k-1)*L + N + offset.

N  = numel(h);
g  = 10^(gdb / 10);
sg = sqrt(0.25 / g);
a0 = 1 / sqrt(2);
M  = 2e5;                                   % symboles par bloc
nerr = 0;  nb = 0;
while nerr < ncible && nb < nmax
    b = rand(1, M) < 0.5;
    a = a0 * (1 - 2*b);                     % symboles +-a0
    x = zeros(1, M*L);  x(1:L:end) = a;     % sur-échantillonnage : un symbole tous les L échantillons
    s = filter(h, 1, [x zeros(1, N-1)]);    % mise en forme (+ vidage du filtre)
    r = s + sg * randn(size(s));            % canal à bruit blanc gaussien
    z = filter(fliplr(h), 1, r);            % filtre adapté h(-t)
    idx = (0:M-1) * L + N + offset;         % instants d'échantillonnage
    nerr = nerr + sum((z(idx) < 0) ~= b);   % décision au seuil nul : bit 1 si z < 0
    nb = nb + M;
end
teb = nerr / nb;
end