function Pb = pb_hamming(p, methode)
%PB_HAMMING  Probabilité d'erreur sur un bit d'information après décodage du code de Hamming (7,4).
%   Pb = pb_hamming(p, methode)
%   p       : probabilité d'erreur sur un bit codé (scalaire ou vecteur)
%   methode : 'exact' (défaut) : énumération des 128 motifs d'erreur
%             'approx'        : approximation du sujet, j erreurs -> j/7 bits faux (j >= 2), optimiste
%
%   Le code étant linéaire, le résultat ne dépend que du motif d'erreur e : on décode le mot reçu
%   r = e (mot-code nul + erreur), et les bits à 1 dans le message décodé sont les bits faux.
if nargin < 2, methode = 'exact'; end
Pb = zeros(size(p));
switch methode
    case 'exact'
        E     = dec2bin(0:127) - '0';            % les 128 motifs d'erreur
        nfaux = sum(hamming_decode(E), 2);       % bits d'information faux pour chaque motif
        w     = sum(E, 2);                       % poids du motif
        for i = 1:numel(p)
            Pb(i) = sum(p(i).^w .* (1 - p(i)).^(7 - w) .* nfaux) / 4;
        end
    case 'approx'
        j  = 2:7;
        nc = arrayfun(@(jj) nchoosek(7, jj), j);
        for i = 1:numel(p)
            Pb(i) = sum((j/7) .* nc .* p(i).^j .* (1 - p(i)).^(7 - j));
        end
    otherwise
        error('methode inconnue : ''exact'' ou ''approx''');
end
end
