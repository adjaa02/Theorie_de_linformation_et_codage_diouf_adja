function oeil(z, N, L, ntr, off)
%OEIL  Diagramme de l'oeil : ntr traces de deux durées symbole, centrées sur l'instant d'échantillonnage.
%   oeil(z, N, L, ntr, off)
%   z   : sortie du filtre adapté (une voie)
%   N   : longueur des filtres (retard de la chaîne = N-1 échantillons)
%   L   : échantillons par symbole
%   ntr : nombre de traces superposées
%   off : (facultatif) décalage de l'instant d'échantillonnage en échantillons, tracé en rouge

if nargin < 5, off = 0; end
k0 = 20;                                    % on saute le régime transitoire
t  = (-L:L) / L;                            % en unités de T, 0 = instant d'échantillonnage idéal
hold on;
for k = k0 : k0 + ntr - 1
    c = (k-1) * L + N;                      % indice de l'instant d'échantillonnage du symbole k
    plot(t, z(c-L : c+L), 'b');
end
yl = ylim;
plot([0 0], yl, 'k--', 'LineWidth', 1.2);
if off ~= 0, plot([off off] / L, yl, 'r-', 'LineWidth', 1.5); end
grid on; xlabel('t / T (0 = instant d''echantillonnage ideal)'); ylabel('amplitude');
end