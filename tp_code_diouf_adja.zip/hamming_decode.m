function [mhat, chat, s] = hamming_decode(r)
%HAMMING_DECODE  Décodeur de Hamming (7,4) par calcul du syndrome.
%   [mhat, chat, s] = hamming_decode(r)
%   r    : matrice N x 7 de bits reçus (un mot par ligne)
%   mhat : N x 4, messages décodés (4 premiers bits du mot corrigé)
%   chat : N x 7, mots corrigés
%   s    : N x 3, syndromes
%
%   Principe : s = r*H' (modulo 2). Si s = 0, aucune erreur détectée. Sinon,
%   s est égal à la colonne de H correspondant à la position de l'erreur
%   (si l'erreur est simple) : on inverse ce bit.

[~, H] = hamming_GH();
s = mod(r * H.', 2);                 % syndromes, N x 3

Hdec = [4 2 1] * H;                  % chaque colonne de H lue comme un nombre (1..7)
pos  = zeros(8, 1);
pos(Hdec + 1) = 1:7;                 % pos(syndrome + 1) = position de l'erreur

sd   = s * [4; 2; 1];                % syndromes lus comme des nombres (0..7)
chat = r;
err  = find(sd > 0);                 % mots dont le syndrome est non nul
lin  = sub2ind(size(chat), err, pos(sd(err) + 1));
chat(lin) = 1 - chat(lin);           % correction : on inverse le bit désigné

mhat = chat(:, 1:4);
end