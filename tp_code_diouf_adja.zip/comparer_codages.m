function R = comparer_codages(texte, tag)
%COMPARER_CODAGES  Compare, en bits par caractère, plusieurs façons de coder un texte.
%   R = comparer_codages(texte, tag)
%   texte : chaîne de caractères
%   tag   : nom (sans extension) des fichiers temporaires créés pour les compresseurs
%   R     : structure avec les champs
%           fixe, H0, huff, H2 (= H(X1X2)/2), gzip, bzip2, sevenz  (bits/caractère)
%   bzip2 et sevenz valent NaN si 7-Zip n'est pas trouvé sur l'ordinateur.

Nc = numel(texte);

% --- ordre 0 : fréquences des caractères ---
[H0, sym, p] = entropie(texte);
n = numel(sym);
[~, idx] = ismember(texte, sym);
R.fixe = ceil(log2(n));                 % code de longueur fixe
R.H0   = H0;                            % entropie d'ordre 0
[~, R.huff] = huffman(p);          % longueur moyenne de Huffman

% --- ordre 2 : entropie des paires de caractères consécutifs ---
paires = (idx(1:end-1) - 1) * n + idx(2:end);   % une paire -> un entier
R.H2   = entropie(paires(:).') / 2;             % bits par caractère

% --- compresseurs réels : on écrit le texte en UTF-8 puis on compresse ---
f = [tag '.txt'];
fid = fopen(f, 'w');
fwrite(fid, unicode2native(texte, 'UTF-8'), 'uint8');
fclose(fid);

gzip(f);                                % crée tag.txt.gz
d = dir([f '.gz']);
R.gzip = 8 * d.bytes / Nc;

R.bzip2 = NaN;  R.sevenz = NaN;
exe = '7z';
if ispc && exist('C:\Program Files\7-Zip\7z.exe', 'file')
    exe = '"C:\Program Files\7-Zip\7z.exe"';
end
if exist([tag '.7z'],  'file'), delete([tag '.7z']);  end
if exist([tag '.bz2'], 'file'), delete([tag '.bz2']); end
[st, ~] = system(sprintf('%s a -t7z -mx=9 -y %s.7z %s', exe, tag, f));
if st == 0
    d = dir([tag '.7z']);  R.sevenz = 8 * d.bytes / Nc;
end
[st, ~] = system(sprintf('%s a -tbzip2 -y %s.bz2 %s', exe, tag, f));
if st == 0
    d = dir([tag '.bz2']); R.bzip2 = 8 * d.bytes / Nc;
end

fprintf('Paires distinctes observees : %d sur %d possibles (%d paires lues)\n', ...
        numel(unique(paires)), n^2, numel(paires));
end